using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Owns and updates every piece of in-game UI.
/// Subscribes to GameManager events so it never needs to poll values.
///
/// ASSIGNMENT COMPLIANCE:
///  ✓ Health bar (Slider) visible on HUD
///  ✓ Health shown as number (healthValueText)
///  ✓ Score shown as number (scoreText)
///  ✓ Health bar fill colour gradient: green (full) → yellow (50%) → red (low)
///  ✓ Game Over panel shown when health reaches 0
///  ✓ Floating score/heal popups for readability
///
/// Attach to an empty "UIManager" GameObject in the scene.
/// Wire all serialized fields in the Inspector.
/// </summary>
public class UIManager : MonoBehaviour
{
    // ─── Singleton ────────────────────────────────────────────────────────────
    public static UIManager Instance { get; private set; }

    // ─── HUD References ───────────────────────────────────────────────────────
    [Header("HUD – Score")]
    [SerializeField] private TextMeshProUGUI scoreText;

    [Header("HUD – Health")]
    [SerializeField] private Slider          healthSlider;
    [SerializeField] private Image           healthBarFill;   // Slider > Fill Area > Fill
    [SerializeField] private TextMeshProUGUI healthValueText; // e.g. "75 / 100"

    [Header("Game Over Panel")]
    [SerializeField] private GameObject      gameOverPanel;
    [SerializeField] private TextMeshProUGUI finalScoreText;

    [Header("Score Popups")]
    [Tooltip("Prefab with a TextMeshPro component + ScorePopup script.")]
    [SerializeField] private GameObject scorePopupPrefab;
    [Tooltip("World-space canvas used as the popup parent.")]
    [SerializeField] private Canvas     worldCanvas;

    [Header("Fury Mode Label")]
    [SerializeField] private GameObject furyModeLabel; // pulsing "FURY MODE" text object

    // ─── Health Bar Gradient ──────────────────────────────────────────────────
    private static readonly Color ColorFull = new Color(0.20f, 0.90f, 0.30f); // green
    private static readonly Color ColorMid  = new Color(1.00f, 0.85f, 0.00f); // yellow
    private static readonly Color ColorLow  = new Color(1.00f, 0.15f, 0.10f); // red

    // ─────────────────────────────────────────────────────────────────────────
    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
    }

    private void Start()
    {
        // Subscribe to GameManager events
        if (GameManager.Instance != null)
        {
            GameManager.Instance.OnHealthChanged += UpdateHealthUI;
            GameManager.Instance.OnScoreChanged  += UpdateScoreUI;
        }

        // Initialise display
        int hp  = GameManager.Instance?.CurrentHealth ?? 100;
        int max = GameManager.Instance?.MaxHealth     ?? 100;
        UpdateHealthUI(hp, max);
        UpdateScoreUI(0);

        if (gameOverPanel != null) gameOverPanel.SetActive(false);
        if (furyModeLabel != null) furyModeLabel.SetActive(false);
    }

    private void OnDestroy()
    {
        if (GameManager.Instance != null)
        {
            GameManager.Instance.OnHealthChanged -= UpdateHealthUI;
            GameManager.Instance.OnScoreChanged  -= UpdateScoreUI;
        }
    }

    // ─── Health UI ────────────────────────────────────────────────────────────

    private void UpdateHealthUI(int current, int max)
    {
        // Slider
        if (healthSlider != null)
        {
            healthSlider.maxValue = max;
            healthSlider.value    = current;
        }

        // Numeric label
        if (healthValueText != null)
            healthValueText.text = $"{current} / {max}";

        // Animated gradient fill colour
        if (healthBarFill != null)
        {
            float t = max > 0 ? (float)current / max : 0f;
            Color c = t > 0.5f
                ? Color.Lerp(ColorMid, ColorFull, (t - 0.5f) * 2f)  // yellow → green
                : Color.Lerp(ColorLow, ColorMid,   t         * 2f);  // red    → yellow
            healthBarFill.color = c;
        }
    }

    // ─── Score UI ─────────────────────────────────────────────────────────────

    private void UpdateScoreUI(int score)
    {
        if (scoreText != null)
            scoreText.text = $"SCORE  {score:D5}";
    }

    // ─── Game Over ────────────────────────────────────────────────────────────

    /// <summary>Called by GameManager.DeathSequence after the slow-motion moment.</summary>
    public void ShowGameOverPanel(int finalScore)
    {
        if (gameOverPanel != null) gameOverPanel.SetActive(true);
        if (finalScoreText != null)
            finalScoreText.text = $"FINAL SCORE\n{finalScore:D5}";
    }

    // ─── Score Popup ──────────────────────────────────────────────────────────

    /// <summary>
    /// Instantiates a floating score popup at a world position.
    /// isHeal = true renders "+30 HP" in green instead of "+50" in yellow.
    /// </summary>
    public void SpawnScorePopup(int amount, Vector3 worldPosition, bool isHeal = false)
    {
        if (scorePopupPrefab == null || worldCanvas == null) return;

        GameObject popup = Instantiate(scorePopupPrefab, worldPosition, Quaternion.identity,
                                       worldCanvas.transform);
        popup.GetComponent<ScorePopup>()?.Setup(amount, isHeal);
    }

    // ─── Fury Mode Label ──────────────────────────────────────────────────────

    /// <summary>Called by FuryModeController when fury state changes.</summary>
    public void SetFuryModeActive(bool active)
    {
        if (furyModeLabel != null) furyModeLabel.SetActive(active);
    }
}
