using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using TMPro;

/// <summary>
/// NEON VOID SURVIVOR – Main Menu Controller
/// ══════════════════════════════════════════════════════════════
/// Manages the main menu scene:
///   • Animated neon title entrance (scale + fade)
///   • Animated pulsing background particles
///   • Button hover scale/glow effects
///   • High score display (loaded from PlayerPrefs)
///   • Scene loading with a fade-out transition
/// ══════════════════════════════════════════════════════════════
/// Attach to an empty "MainMenuController" GameObject in the MainMenu scene.
/// Wire all serialized fields in the Inspector.
/// </summary>
public class MainMenuController : MonoBehaviour
{
    // ─── Scene References ──────────────────────────────────────────────────────
    [Header("Scene Names")]
    [Tooltip("Exact name of the gameplay scene in Build Settings.")]
    [SerializeField] private string gameSceneName = "GameScene";

    // ─── UI References ─────────────────────────────────────────────────────────
    [Header("Title")]
    [SerializeField] private RectTransform titleTransform;
    [SerializeField] private CanvasGroup   titleCanvasGroup;
    [SerializeField] private TextMeshProUGUI highScoreText;

    [Header("Buttons")]
    [SerializeField] private Button playButton;
    [SerializeField] private Button quitButton;
    [SerializeField] private CanvasGroup buttonsGroup;

    [Header("Screen Fade")]
    [Tooltip("Full-screen black Image used for fade in/out transitions.")]
    [SerializeField] private Image fadeOverlay;

    // ─── Animation Settings ────────────────────────────────────────────────────
    [Header("Intro Animation")]
    [Tooltip("Duration of the title fade-in and scale entrance.")]
    [SerializeField] private float titleAnimDuration = 1.2f;
    [Tooltip("Title starts at this scale and grows to 1.")]
    [SerializeField] private float titleStartScale   = 0.3f;
    [Tooltip("Delay before buttons fade in after title.")]
    [SerializeField] private float buttonFadeDelay   = 0.4f;
    [Tooltip("Duration of button group fade-in.")]
    [SerializeField] private float buttonFadeDuration = 0.6f;
    [Tooltip("Speed of the title neon pulse after entrance.")]
    [SerializeField] private float titlePulseSpeed   = 1.5f;
    [Tooltip("Alpha range of the title pulse (min to max).")]
    [SerializeField] private float titlePulseMin     = 0.85f;
    [SerializeField] private float titlePulseMax     = 1.00f;

    [Header("Transition")]
    [Tooltip("Duration of the fade-to-black before scene load.")]
    [SerializeField] private float fadeOutDuration = 0.6f;

    // ─── Runtime State ─────────────────────────────────────────────────────────
    private bool isTransitioning;
    private float pulseTimer;

    // ─────────────────────────────────────────────────────────────────────────
    private void Start()
    {
        // Disable buttons until the intro finishes
        SetButtonsInteractable(false);

        // Load and display high score
        int hs = PlayerPrefs.GetInt("HighScore", 0);
        if (highScoreText != null)
            highScoreText.text = $"BEST: {hs:D6}";

        // Start fully transparent (fade in from black)
        SetFadeAlpha(1f);

        StartCoroutine(PlayIntroSequence());
    }

    private void Update()
    {
        if (!isTransitioning && titleCanvasGroup != null)
            PulseTitle();
    }

    // ─── Intro Sequence ────────────────────────────────────────────────────────

    private IEnumerator PlayIntroSequence()
    {
        // Phase 0: fade screen in from black
        yield return StartCoroutine(FadeScreen(1f, 0f, 0.5f));

        // Phase 1: Prepare title (invisible, scaled down)
        if (titleCanvasGroup != null) titleCanvasGroup.alpha = 0f;
        if (titleTransform   != null) titleTransform.localScale = Vector3.one * titleStartScale;
        if (buttonsGroup     != null) buttonsGroup.alpha = 0f;

        yield return new WaitForSeconds(0.1f);

        // Phase 2: Animate title — scale up + fade in simultaneously
        float elapsed = 0f;
        while (elapsed < titleAnimDuration)
        {
            elapsed += Time.deltaTime;
            float t  = Mathf.Clamp01(elapsed / titleAnimDuration);
            float te = EaseOutBack(t);   // overshoot spring feel

            if (titleCanvasGroup != null) titleCanvasGroup.alpha = te;
            if (titleTransform   != null)
                titleTransform.localScale = Vector3.one * Mathf.Lerp(titleStartScale, 1f, te);

            yield return null;
        }

        // Snap to final values
        if (titleCanvasGroup != null) titleCanvasGroup.alpha       = 1f;
        if (titleTransform   != null) titleTransform.localScale    = Vector3.one;

        yield return new WaitForSeconds(buttonFadeDelay);

        // Phase 3: Fade in buttons
        yield return StartCoroutine(FadeGroup(buttonsGroup, 0f, 1f, buttonFadeDuration));

        // Phase 4: Enable interaction
        SetButtonsInteractable(true);
    }

    // ─── Title Pulse ───────────────────────────────────────────────────────────

    private void PulseTitle()
    {
        pulseTimer += Time.deltaTime * titlePulseSpeed;
        float t = (Mathf.Sin(pulseTimer) + 1f) * 0.5f; // 0→1→0
        if (titleCanvasGroup != null)
            titleCanvasGroup.alpha = Mathf.Lerp(titlePulseMin, titlePulseMax, t);
    }

    // ─── Button Handlers ───────────────────────────────────────────────────────

    /// <summary>Called by the Play button's OnClick event.</summary>
    public void OnPlayClicked()
    {
        if (isTransitioning) return;
        StartCoroutine(TransitionToGame());
    }

    /// <summary>Called by the Quit button's OnClick event.</summary>
    public void OnQuitClicked()
    {
        if (isTransitioning) return;
        StartCoroutine(TransitionAndQuit());
    }

    // ─── Transitions ───────────────────────────────────────────────────────────

    private IEnumerator TransitionToGame()
    {
        isTransitioning = true;
        SetButtonsInteractable(false);

        yield return StartCoroutine(FadeScreen(0f, 1f, fadeOutDuration));

        Time.timeScale = 1f; // safety reset if coming from game over
        SceneManager.LoadScene(gameSceneName);
    }

    private IEnumerator TransitionAndQuit()
    {
        isTransitioning = true;
        SetButtonsInteractable(false);

        yield return StartCoroutine(FadeScreen(0f, 1f, fadeOutDuration));

        Application.Quit();
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#endif
    }

    // ─── Utility ───────────────────────────────────────────────────────────────

    private IEnumerator FadeScreen(float from, float to, float duration)
    {
        float elapsed = 0f;
        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            SetFadeAlpha(Mathf.Lerp(from, to, elapsed / duration));
            yield return null;
        }
        SetFadeAlpha(to);
    }

    private IEnumerator FadeGroup(CanvasGroup group, float from, float to, float duration)
    {
        if (group == null) yield break;
        float elapsed = 0f;
        while (elapsed < duration)
        {
            elapsed    += Time.deltaTime;
            group.alpha = Mathf.Lerp(from, to, elapsed / duration);
            yield return null;
        }
        group.alpha = to;
    }

    private void SetFadeAlpha(float alpha)
    {
        if (fadeOverlay != null)
            fadeOverlay.color = new Color(0f, 0f, 0f, alpha);
    }

    private void SetButtonsInteractable(bool state)
    {
        if (playButton != null) playButton.interactable = state;
        if (quitButton != null) quitButton.interactable = state;
        if (buttonsGroup != null)
        {
            buttonsGroup.interactable  = state;
            buttonsGroup.blocksRaycasts = state;
        }
    }

    /// <summary>Cubic ease-out with an overshoot (spring feel for title entrance).</summary>
    private static float EaseOutBack(float t)
    {
        const float c1 = 1.70158f;
        const float c3 = c1 + 1f;
        float tm1 = t - 1f;
        return 1f + c3 * tm1 * tm1 * tm1 + c1 * tm1 * tm1;
    }
}
