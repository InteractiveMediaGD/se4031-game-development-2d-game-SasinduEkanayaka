using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// NEON VOID SURVIVOR – Pause Manager
/// ══════════════════════════════════════════════════════════════
/// Handles pause/resume via the Escape key or a UI button.
/// Freezes time, shows the pause panel, and resumes cleanly.
///
/// Also provides a Resume button callback and a "Main Menu" button
/// that safely returns to the main menu from a paused state.
/// ══════════════════════════════════════════════════════════════
/// Attach to an empty "PauseManager" GameObject in the Game scene.
/// Wire all serialized fields in the Inspector.
/// </summary>
public class PauseManager : MonoBehaviour
{
    // ─── Singleton ─────────────────────────────────────────────────────────────
    public static PauseManager Instance { get; private set; }

    // ─── UI References ─────────────────────────────────────────────────────────
    [Header("UI")]
    [Tooltip("The pause panel GameObject (Panel/Canvas Group).")]
    [SerializeField] private GameObject pausePanel;

    [Tooltip("Optional: blur/darken overlay behind the pause panel.")]
    [SerializeField] private GameObject pauseOverlay;

    [Tooltip("Resume button (also used for the keyboard shortcut).")]
    [SerializeField] private Button resumeButton;

    // ─── Scene Reference ────────────────────────────────────────────────────────
    [Header("Scene")]
    [SerializeField] private string mainMenuSceneName = "MainMenu";

    // ─── State ─────────────────────────────────────────────────────────────────
    private bool isPaused;
    public bool IsPaused => isPaused;

    // ─────────────────────────────────────────────────────────────────────────
    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
    }

    private void Start()
    {
        // Ensure panel is hidden at game start
        SetPanelVisible(false);
    }

    private void Update()
    {
        // Don't allow pause after game over
        if (GameManager.Instance != null && GameManager.Instance.IsGameOver) return;

        if (Input.GetKeyDown(KeyCode.Escape))
            TogglePause();
    }

    // ─── Public API ────────────────────────────────────────────────────────────

    /// <summary>Toggles pause on/off. Called by Escape key or the pause button.</summary>
    public void TogglePause()
    {
        if (isPaused) Resume();
        else          Pause();
    }

    /// <summary>Pauses the game. Called from UI pause button or Escape.</summary>
    public void Pause()
    {
        isPaused       = true;
        Time.timeScale = 0f;
        SetPanelVisible(true);
    }

    /// <summary>Resumes the game. Called from UI resume button or Escape.</summary>
    public void Resume()
    {
        isPaused       = false;
        Time.timeScale = 1f;
        SetPanelVisible(false);
    }

    /// <summary>
    /// Returns to the main menu from a paused state.
    /// Resets time scale before loading so the new scene isn't frozen.
    /// </summary>
    public void GoToMainMenu()
    {
        isPaused       = false;
        Time.timeScale = 1f;
        UnityEngine.SceneManagement.SceneManager.LoadScene(mainMenuSceneName);
    }

    // ─── Helpers ───────────────────────────────────────────────────────────────

    private void SetPanelVisible(bool visible)
    {
        if (pausePanel   != null) pausePanel.SetActive(visible);
        if (pauseOverlay != null) pauseOverlay.SetActive(visible);
    }
}
