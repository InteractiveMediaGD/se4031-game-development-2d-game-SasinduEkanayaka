using UnityEngine;

/// <summary>
/// Spawns obstacles, enemies, and health packs at the right edge of the screen.
/// Uses distance-based tracking so obstacle spacing stays VISUALLY consistent
/// regardless of scroll speed – faster speed = obstacles appear more frequently.
///
/// Why distance-based instead of time-based:
///   Time-based (every N seconds): gaps shrink as speed increases → gameplay changes unexpectedly.
///   Distance-based (every N world units): gaps stay physically the same → fair and readable.
///
/// Attach to an empty "SpawnManager" GameObject in the scene.
/// </summary>
public class SpawnManager : MonoBehaviour
{
    [Header("Prefabs")]
    [SerializeField] private GameObject obstaclePrefab;
    [SerializeField] private GameObject enemyPrefab;
    [SerializeField] private GameObject healthPackPrefab;

    [Header("Spawn X Position")]
    [Tooltip("World X where objects are born (just off the right edge of camera).")]
    [SerializeField] private float spawnX = 13f;

    [Header("Obstacle Settings")]
    [Tooltip("World units between the centre of consecutive obstacles.")]
    [SerializeField] private float obstacleSpacing = 10f;
    [Tooltip("Minimum Y for the gap centre.")]
    [SerializeField] private float minGapY = -2f;
    [Tooltip("Maximum Y for the gap centre.")]
    [SerializeField] private float maxGapY = 2f;
    [Tooltip("Vertical height of the navigable gap.")]
    [SerializeField] private float gapHeight = 3.5f;

    [Header("Enemy Settings")]
    [Tooltip("Average world units between enemy spawns.")]
    [SerializeField] private float enemySpacingBase = 8f;
    [Tooltip("±Variance added to spacing for unpredictability.")]
    [SerializeField] private float enemySpacingVariance = 3f;
    [Tooltip("Y range enemies can spawn in.")]
    [SerializeField] private float enemySpawnRangeY = 3f;

    [Header("Health Pack Settings")]
    [Tooltip("Average world units between health pack spawns (rare).")]
    [SerializeField] private float healthPackSpacingBase = 28f;
    [Tooltip("±Variance for health pack spacing.")]
    [SerializeField] private float healthPackSpacingVariance = 8f;

    // ─── Internal distance tracking ───────────────────────────────────────────
    private float distanceTraveled;
    private float nextObstacleAt;
    private float nextEnemyAt;
    private float nextHealthPackAt;

    private void Start()
    {
        // Stagger first spawns so the player has a moment to orient
        nextObstacleAt   = obstacleSpacing * 0.8f;
        nextEnemyAt      = enemySpacingBase * 1.5f;
        nextHealthPackAt = healthPackSpacingBase;
    }

    private void Update()
    {
        if (GameManager.Instance == null || GameManager.Instance.IsGameOver) return;

        // Advance virtual distance by how far the world has scrolled this frame
        distanceTraveled += GameManager.Instance.ScrollSpeed * Time.deltaTime;

        // ── Obstacles ─────────────────────────────────────────────────────────
        if (distanceTraveled >= nextObstacleAt)
        {
            SpawnObstacle();
            nextObstacleAt += obstacleSpacing;
        }

        // ── Enemies ───────────────────────────────────────────────────────────
        if (distanceTraveled >= nextEnemyAt)
        {
            SpawnEnemy();
            float variance = Random.Range(-enemySpacingVariance, enemySpacingVariance);
            nextEnemyAt += Mathf.Max(4f, enemySpacingBase + variance);
        }

        // ── Health Packs ──────────────────────────────────────────────────────
        if (distanceTraveled >= nextHealthPackAt)
        {
            SpawnHealthPack();
            float variance = Random.Range(-healthPackSpacingVariance, healthPackSpacingVariance);
            nextHealthPackAt += Mathf.Max(15f, healthPackSpacingBase + variance);
        }
    }

    // ─── Spawn Helpers ────────────────────────────────────────────────────────

    private void SpawnObstacle()
    {
        if (obstaclePrefab == null) return;
        float gapY = Random.Range(minGapY, maxGapY);
        GameObject go = Instantiate(obstaclePrefab, new Vector3(spawnX, 0f, 0f), Quaternion.identity);
        go.GetComponent<ObstacleSegment>()?.Initialize(gapY, gapHeight);
    }

    private void SpawnEnemy()
    {
        if (enemyPrefab == null) return;
        float y = Random.Range(-enemySpawnRangeY, enemySpawnRangeY);
        Instantiate(enemyPrefab, new Vector3(spawnX, y, 0f), Quaternion.identity);
    }

    private void SpawnHealthPack()
    {
        if (healthPackPrefab == null) return;
        float y = Random.Range(-2.5f, 2.5f);
        Instantiate(healthPackPrefab, new Vector3(spawnX, y, 0f), Quaternion.identity);
    }
}
