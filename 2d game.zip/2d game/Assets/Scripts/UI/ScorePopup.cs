using System.Collections;
using TMPro;
using UnityEngine;

/// <summary>
/// Floating "+100" / "+30 HP" popup that drifts upward and fades out.
/// Spawned by UIManager.SpawnScorePopup() on a World-Space canvas.
///
/// Prefab setup:
///   ScorePopup (this script, RectTransform)
///   └── Text (TextMeshProUGUI)
///
/// Canvas must be set to Render Mode: World Space.
/// Uses Time.unscaledDeltaTime so popups animate even during slow-motion.
/// </summary>
public class ScorePopup : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI label;
    [SerializeField] private float floatSpeed = 1.8f;   // world units/second upward drift
    [SerializeField] private float lifetime   = 0.95f;  // seconds before destroy

    // Gap-score colour (gold-yellow) vs heal colour (bright green)
    private static readonly Color ColorScore = new Color(1.00f, 0.90f, 0.20f);
    private static readonly Color ColorHeal  = new Color(0.25f, 1.00f, 0.40f);

    public void Setup(int amount, bool isHeal = false)
    {
        if (label == null) label = GetComponentInChildren<TextMeshProUGUI>();
        if (label == null) { Destroy(gameObject); return; }

        label.text  = isHeal ? $"+{amount} HP" : $"+{amount}";
        label.color = isHeal ? ColorHeal : ColorScore;

        StartCoroutine(AnimateAndDestroy());
    }

    private IEnumerator AnimateAndDestroy()
    {
        float elapsed = 0f;
        Color startColor = label.color;

        while (elapsed < lifetime)
        {
            float dt = Time.unscaledDeltaTime;
            elapsed += dt;

            // Drift upward
            transform.position += Vector3.up * floatSpeed * dt;

            // Fade out
            float alpha = Mathf.Lerp(1f, 0f, elapsed / lifetime);
            label.color = new Color(startColor.r, startColor.g, startColor.b, alpha);

            yield return null;
        }

        Destroy(gameObject);
    }
}
