using UnityEngine;

/// <summary>
/// Runic Shade enemy – a hostile floating apparition that drifts leftward
/// with a sinusoidal vertical movement for organic, threatening feel.
///
/// ASSIGNMENT COMPLIANCE:
///  ✓ Collidable via CircleCollider2D trigger
///  ✓ Destroyed by projectile collision (awardScore = true → +50 pts)
///  ✓ Destroyed by player contact  (awardScore = false → no score)
///  ✓ Player health decreases on contact (handled by PlayerHealth.OnTriggerEnter2D)
///  ✓ Destroyed when it passes off-screen (AutoDestroyOffscreen component)
///  ✓ Visually distinct: triangular / diamond shape, different color from health packs
///
/// GameObject setup:
///   Tag: "Enemy"
///   Layer: Default (or dedicated Enemy layer)
///   CircleCollider2D: isTrigger = true
///   AutoDestroyOffscreen component attached
/// </summary>
public class EnemyController : MonoBehaviour
{
    [Header("Scoring")]
    [Tooltip("Score awarded when destroyed by a player projectile.")]
    [SerializeField] private int killScoreValue = 50;

    [Header("Wave Movement")]
    [Tooltip("How far the enemy drifts vertically (0 = straight flight).")]
    [SerializeField] private float waveAmplitude = 0.55f;
    [Tooltip("Speed of the sinusoidal vertical oscillation.")]
    [SerializeField] private float waveFrequency = 1.8f;
    [Tooltip("Speed multiplier relative to world scroll speed (1.1 = slightly faster).")]
    [SerializeField] private float speedMultiplier = 1.1f;

    [Header("Effects")]
    [Tooltip("Optional particle effect spawned on death.")]
    [SerializeField] private GameObject deathParticlePrefab;

    // Runtime state
    private float startY;
    private float birthTime;
    private bool isDead; // guard against double-destroy if two triggers fire same frame

    private void OnEnable()
    {
        // Reset each time the object is activated (safe for future object pooling)
        startY   = transform.position.y;
        birthTime = Time.time;
        isDead   = false;
    }

    private void Update()
    {
        if (GameManager.Instance == null || GameManager.Instance.IsGameOver) return;

        // Move leftward at slightly more than world speed (creates overtaking pressure)
        float scrollSpeed = GameManager.Instance.ScrollSpeed * speedMultiplier;
        transform.Translate(Vector3.left * scrollSpeed * Time.deltaTime);

        // Sinusoidal Y drift – makes it harder to avoid and visually interesting
        float newY = startY + Mathf.Sin((Time.time - birthTime) * waveFrequency) * waveAmplitude;
        transform.position = new Vector3(transform.position.x, newY, 0f);
    }

    // OnTriggerEnter2D for "Player" tag is intentionally handled in PlayerHealth.cs
    // to avoid duplicating the damage call. The enemy just needs DestroyEnemy().

    /// <summary>
    /// Destroys this enemy and optionally awards score.
    /// Called by: Projectile (awardScore=true) or PlayerHealth (awardScore=false).
    /// </summary>
    public void DestroyEnemy(bool awardScore)
    {
        if (isDead) return; // prevent double-execution
        isDead = true;

        if (awardScore)
        {
            GameManager.Instance?.AddEnemyKillScore();
            // Spawn a floating "+50" popup at the enemy's world position
            UIManager.Instance?.SpawnScorePopup(killScoreValue, transform.position);
        }

        // Visual death effect
        if (deathParticlePrefab != null)
            Instantiate(deathParticlePrefab, transform.position, Quaternion.identity);

        Destroy(gameObject);
    }
}
