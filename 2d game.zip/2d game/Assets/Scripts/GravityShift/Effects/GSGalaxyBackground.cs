using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// GRAVITY SHIFT: CORE ESCAPE — Galaxy Background Effect (Main Menu)
/// ══════════════════════════════════════════════════════════════
/// Creates a multi-layer star field with:
///   • Tiny bright white stars (far layer, very slow)
///   • Medium colored nebula dots (mid layer, slow drift)
///   • Large glowing orbs (near layer, visible movement)
///
/// All layers wrap seamlessly when they drift off screen.
/// Color palette: deep blues, purples, teals — matches the game's
/// dark space glassmorphism theme.
/// ══════════════════════════════════════════════════════════════
/// Attach to "GalaxyBackground" in the MainMenu scene.
/// Assign a white circle sprite prefab to starPrefab.
/// </summary>
public class GSGalaxyBackground : MonoBehaviour
{
    // ─── Prefab ────────────────────────────────────────────────────────────────
    [Header("Star Prefab")]
    [Tooltip("A simple white circle sprite (Unlit/Transparent material).")]
    [SerializeField] private GameObject starPrefab;

    // ─── Layer Config ──────────────────────────────────────────────────────────
    [System.Serializable]
    public class StarLayer
    {
        public int   count        = 50;
        public float minSize      = 0.02f;
        public float maxSize      = 0.08f;
        public float driftSpeed   = 0.1f;   // downward drift for parallax
        public float horizontalDrift = 0.02f;
        [Range(0f, 1f)]
        public float brightness   = 0.7f;
        public int   sortingOrder = -15;
    }

    [Header("Layers")]
    [SerializeField] private StarLayer farLayer  = new StarLayer { count = 80, minSize = 0.01f, maxSize = 0.05f, driftSpeed = 0.06f, brightness = 0.5f, sortingOrder = -15 };
    [SerializeField] private StarLayer midLayer  = new StarLayer { count = 40, minSize = 0.05f, maxSize = 0.12f, driftSpeed = 0.14f, brightness = 0.7f, sortingOrder = -14 };
    [SerializeField] private StarLayer nearLayer = new StarLayer { count = 15, minSize = 0.15f, maxSize = 0.35f, driftSpeed = 0.28f, brightness = 0.4f, sortingOrder = -13 };

    [Header("Bounds")]
    [SerializeField] private float spawnW = 12f;
    [SerializeField] private float spawnH = 7f;

    // ─── Palette ───────────────────────────────────────────────────────────────
    private static readonly Color[] StarColors =
    {
        new Color(0.80f, 0.85f, 1.00f), // near-white blue
        new Color(0.55f, 0.30f, 1.00f), // violet
        new Color(0.20f, 0.70f, 1.00f), // cyan-blue
        new Color(0.00f, 1.00f, 0.80f), // teal
        new Color(0.90f, 0.50f, 1.00f), // pink-purple
    };

    // ─── Runtime Data ──────────────────────────────────────────────────────────
    private struct Star
    {
        public Transform       t;
        public SpriteRenderer  sr;
        public float           driftY;
        public float           driftX;
        public float           phase;
        public float           pulseSpeed;
        public Color           baseColor;
    }

    private List<Star> stars = new List<Star>();

    // ─────────────────────────────────────────────────────────────────────────
    private void Start()
    {
        if (starPrefab == null) { enabled = false; return; }
        SpawnLayer(farLayer);
        SpawnLayer(midLayer);
        SpawnLayer(nearLayer);
    }

    private void SpawnLayer(StarLayer layer)
    {
        for (int i = 0; i < layer.count; i++)
        {
            float x = Random.Range(-spawnW, spawnW);
            float y = Random.Range(-spawnH, spawnH);
            float s = Random.Range(layer.minSize, layer.maxSize);

            GameObject go = Instantiate(starPrefab, new Vector3(x, y, 0f), Quaternion.identity, transform);
            go.transform.localScale = Vector3.one * s;

            Color c  = StarColors[Random.Range(0, StarColors.Length)];
            c.a      = layer.brightness;

            SpriteRenderer sr = go.GetComponent<SpriteRenderer>();
            if (sr != null)
            {
                sr.color        = c;
                sr.sortingOrder = layer.sortingOrder;
            }

            stars.Add(new Star
            {
                t           = go.transform,
                sr          = sr,
                driftY      = layer.driftSpeed,
                driftX      = Random.Range(-layer.horizontalDrift, layer.horizontalDrift),
                phase       = Random.Range(0f, Mathf.PI * 2f),
                pulseSpeed  = Random.Range(0.5f, 2.5f),
                baseColor   = c,
            });
        }
    }

    private void Update()
    {
        float dt = Time.deltaTime;
        for (int i = 0; i < stars.Count; i++)
        {
            Star s = stars[i];
            if (s.t == null) continue;

            // Drift movement
            Vector3 pos = s.t.position;
            pos.y -= s.driftY * dt;
            pos.x += s.driftX * dt;
            s.t.position = pos;

            // Wrap vertical
            if (pos.y < -spawnH) { pos.y = spawnH; pos.x = Random.Range(-spawnW, spawnW); s.t.position = pos; }
            if (pos.x < -spawnW) pos.x = spawnW;
            else if (pos.x > spawnW) pos.x = -spawnW;
            s.t.position = pos;

            // Twinkle pulse
            if (s.sr != null)
            {
                float t = (Mathf.Sin(Time.time * s.pulseSpeed + s.phase) + 1f) * 0.5f;
                Color c = s.baseColor;
                c.a = Mathf.Lerp(s.baseColor.a * 0.4f, s.baseColor.a, t);
                s.sr.color = c;
            }

            stars[i] = s;
        }
    }
}
