using UnityEngine;

/// <summary>
/// GRAVITY SHIFT: CORE ESCAPE — Wall Segment (Obstacle)
/// ══════════════════════════════════════════════════════════════
/// Two wall panels with a gap between them. Spawned at the right
/// edge and scrolls leftward according to game speed.
///
/// The gap position is randomized by GSObstacleSpawner.
///
/// Prefab Hierarchy:
///   GSWallSegment  [this script, AutoDestroy]
///   ├── TopPanel   [SpriteRenderer, BoxCollider2D trigger, Tag=GSObstacle]
///   └── BotPanel   [SpriteRenderer, BoxCollider2D trigger, Tag=GSObstacle]
///
/// Both panels use isTrigger = true so the player passes through
/// them (damage via trigger, not physics push).
/// ══════════════════════════════════════════════════════════════
/// </summary>
public class GSWallSegment : MonoBehaviour
{
    [Header("Child References")]
    [SerializeField] private Transform topPanel;
    [SerializeField] private Transform botPanel;

    [Header("Screen Bounds")]
    [SerializeField] private float screenTop    =  5.5f;
    [SerializeField] private float screenBottom = -5.5f;
    [SerializeField] private float panelWidth   =  1.2f;

    [Header("Destroy Threshold")]
    [SerializeField] private float destroyX = -14f;

    // ─────────────────────────────────────────────────────────────────────────

    public void Initialize(float gapCenterY, float gapHeight)
    {
        float halfGap   = gapHeight * 0.5f;
        float gapTop    = gapCenterY + halfGap;
        float gapBottom = gapCenterY - halfGap;

        if (topPanel != null)
        {
            float h = Mathf.Max(0.1f, screenTop - gapTop);
            topPanel.localPosition = new Vector3(0f, gapTop + h * 0.5f, 0f);
            topPanel.localScale    = new Vector3(panelWidth, h, 1f);
        }

        if (botPanel != null)
        {
            float h = Mathf.Max(0.1f, gapBottom - screenBottom);
            botPanel.localPosition = new Vector3(0f, screenBottom + h * 0.5f, 0f);
            botPanel.localScale    = new Vector3(panelWidth, h, 1f);
        }
    }

    private void Update()
    {
        if (GSGameManager.Instance == null) return;

        // Scroll leftward
        float speed = GSGameManager.Instance.CurrentSpeed;
        transform.Translate(Vector3.left * speed * Time.deltaTime);

        // Auto-destroy when off-screen
        if (transform.position.x < destroyX)
            Destroy(gameObject);
    }
}
