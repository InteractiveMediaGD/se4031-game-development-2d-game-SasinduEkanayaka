using System.Collections;
using UnityEngine;

/// <summary>
/// GRAVITY SHIFT: CORE ESCAPE — Creative Feature: GRAVITY CHAOS MODE
/// ══════════════════════════════════════════════════════════════
/// Activates at a score milestone OR when player health drops below threshold.
///
/// What happens during Chaos Mode (15–20 second bursts):
///   1. GravitySystem takes over input → random shifts every 0.6s
///   2. Screen glitch effect (chromatic aberration via GSCameraEffects)
///   3. Background core rotation accelerates dramatically
///   4. Music pitch distortion (if AudioSource is assigned)
///   5. Vignette pulses purple
///   6. Time.timeScale dips to 0.85 (slight slow-motion adds urgency)
///   7. Enemies get a speed boost during chaos
///   8. "CHAOS MODE" label pulses red/purple on the HUD
///
/// Chaos Mode is rewarding if survived — bonus score multiplier is
/// applied for every second spent inside Chaos Mode.
/// ══════════════════════════════════════════════════════════════
/// Attach to an empty "GravityChaosModeController" GameObject.
/// </summary>
public class GravityChaosModeController : MonoBehaviour
{
    // ─── Singleton ─────────────────────────────────────────────────────────────
    public static GravityChaosModeController Instance { get; private set; }

    // ─── Trigger Conditions ────────────────────────────────────────────────────
    [Header("Trigger Conditions")]
    [Tooltip("Score at which Chaos Mode first triggers.")]
    [SerializeField] private int   firstTriggerScore   = 500;
    [Tooltip("Score interval for repeated triggers after the first.")]
    [SerializeField] private int   triggerScoreInterval = 800;
    [Tooltip("Health percent (0-1) that forces an emergency Chaos trigger.")]
    [SerializeField] private float emergencyHealthThreshold = 0.20f;

    // ─── Duration ──────────────────────────────────────────────────────────────
    [Header("Duration")]
    [SerializeField] private float minDuration = 12f;
    [SerializeField] private float maxDuration = 18f;
    [SerializeField] private float cooldownAfter = 8f;

    // ─── Chaos Modifiers ───────────────────────────────────────────────────────
    [Header("Modifiers")]
    [Tooltip("Time.timeScale during Chaos Mode (< 1 = slow-mo feel).")]
    [SerializeField] private float chaosTimeScale        = 0.85f;
    [Tooltip("Score multiplier for each second spent in Chaos Mode.")]
    [SerializeField] private float chaosScoreMultiplier  = 2.5f;

    // ─── Audio ─────────────────────────────────────────────────────────────────
    [Header("Audio")]
    [Tooltip("Background music AudioSource — pitch shifts during chaos.")]
    [SerializeField] private AudioSource musicSource;
    [SerializeField] private float       chaosAudioPitch  = 0.75f;
    [SerializeField] private float       normalAudioPitch = 1.00f;

    // ─── Core Rotator ──────────────────────────────────────────────────────────
    [Header("Core Visual")]
    [SerializeField] private GSCoreRotator coreRotator;

    // ─── State ─────────────────────────────────────────────────────────────────
    private bool  isChaosActive;
    private float cooldownTimer;
    private int   nextTriggerScore;
    private float chaosScoreAccum;

    public bool IsChaosActive => isChaosActive;

    // ─────────────────────────────────────────────────────────────────────────
    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
    }

    private void Start()
    {
        nextTriggerScore = firstTriggerScore;

        if (GSGameManager.Instance != null)
        {
            GSGameManager.Instance.OnScoreChanged  += CheckScoreTrigger;
            GSGameManager.Instance.OnHealthChanged += CheckHealthTrigger;
        }
    }

    private void OnDestroy()
    {
        if (GSGameManager.Instance != null)
        {
            GSGameManager.Instance.OnScoreChanged  -= CheckScoreTrigger;
            GSGameManager.Instance.OnHealthChanged -= CheckHealthTrigger;
        }
    }

    private void Update()
    {
        if (isChaosActive) return;
        if (cooldownTimer > 0f) cooldownTimer -= Time.deltaTime;
    }

    // ─── Trigger Checks ────────────────────────────────────────────────────────

    private void CheckScoreTrigger(int score)
    {
        if (isChaosActive || cooldownTimer > 0f) return;
        if (score >= nextTriggerScore)
        {
            nextTriggerScore += triggerScoreInterval;
            StartCoroutine(ChaosSequence());
        }
    }

    private void CheckHealthTrigger(int current, int max)
    {
        if (isChaosActive || cooldownTimer > 0f) return;
        float pct = max > 0 ? (float)current / max : 0f;
        if (pct <= emergencyHealthThreshold && pct > 0f)
            StartCoroutine(ChaosSequence());
    }

    // ─── Chaos Sequence ────────────────────────────────────────────────────────

    private IEnumerator ChaosSequence()
    {
        if (isChaosActive) yield break;
        isChaosActive = true;

        float duration = Random.Range(minDuration, maxDuration);

        // ── Activate all chaos effects ─────────────────────────────────────────
        GravitySystem.Instance?.StartChaosMode();
        GSUIManager.Instance?.SetChaosModeVisible(true);
        GSCameraEffects.Instance?.TriggerGlitch();
        GSCameraEffects.Instance?.FlashVignette(new Color(0.5f, 0f, 1f));
        if (coreRotator  != null) coreRotator.SetChaosMode(true);
        if (musicSource  != null) StartCoroutine(PitchShift(chaosAudioPitch, 0.4f));
        Time.timeScale = chaosTimeScale;

        Debug.Log("[CHAOS MODE] ACTIVATED! Duration: " + duration.ToString("F1") + "s");

        // ── Main chaos loop ────────────────────────────────────────────────────
        float elapsed = 0f;
        while (elapsed < duration)
        {
            elapsed  += Time.unscaledDeltaTime;
            chaosScoreAccum += chaosScoreMultiplier * Time.unscaledDeltaTime;

            // Add bonus chaos score
            if (chaosScoreAccum >= 1f)
            {
                int pts = Mathf.FloorToInt(chaosScoreAccum);
                chaosScoreAccum -= pts;
                GSGameManager.Instance?.AddScore(pts);
            }

            // Repeated glitch pulses
            if (elapsed % 2f < 0.05f)
                GSCameraEffects.Instance?.TriggerGlitch();

            if (elapsed % 1.5f < 0.05f)
                GSCameraEffects.Instance?.ShakeOnChaos();

            yield return null;
        }

        // ── Deactivate ────────────────────────────────────────────────────────
        GravitySystem.Instance?.StopChaosMode();
        GSUIManager.Instance?.SetChaosModeVisible(false);
        if (coreRotator  != null) coreRotator.SetChaosMode(false);
        if (musicSource  != null) StartCoroutine(PitchShift(normalAudioPitch, 0.6f));
        Time.timeScale = 1f;

        isChaosActive = false;
        cooldownTimer = cooldownAfter;

        Debug.Log("[CHAOS MODE] ENDED.");
    }

    // ─── Audio Pitch Shift ─────────────────────────────────────────────────────

    private IEnumerator PitchShift(float target, float duration)
    {
        if (musicSource == null) yield break;
        float start   = musicSource.pitch;
        float elapsed = 0f;
        while (elapsed < duration)
        {
            elapsed          += Time.unscaledDeltaTime;
            musicSource.pitch = Mathf.Lerp(start, target, elapsed / duration);
            yield return null;
        }
        musicSource.pitch = target;
    }
}
