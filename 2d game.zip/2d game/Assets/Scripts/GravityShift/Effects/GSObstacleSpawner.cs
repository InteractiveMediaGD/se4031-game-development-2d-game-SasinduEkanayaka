using System.Collections;
using UnityEngine;

/// <summary>
/// GRAVITY SHIFT: CORE ESCAPE — Obstacle Spawner
/// ══════════════════════════════════════════════════════════════
/// Spawns wall segments from all 4 sides of the arena.
/// The obstacle type that spawns changes based on the current
/// gravity direction — walls always come from the sides
/// (perpendicular to gravity pull), so the player must dodge
/// while fighting the pull toward the floor.
///
/// Wall types:
///   • FullWall     – spans the full screen with a gap
///   • MovingWall   – slides vertically/horizontally while scrolling
///   • SpikeWall    – narrower gap, more dangerous
/// ══════════════════════════════════════════════════════════════
/// Attach to an empty "GSObstacleSpawner" in the GS_GameScene.
/// </summary>
public class GSObstacleSpawner : MonoBehaviour
{
    [Header("Obstacle Prefabs")]
    [SerializeField] private GameObject wallPrefab;
    [SerializeField] private GameObject movingWallPrefab;

    [Header("Spawn Settings")]
    [SerializeField] private float spawnX             = 11f;   // spawns off right edge
    [SerializeField] private float baseInterval       = 3.0f;
    [SerializeField] private float minInterval        = 1.2f;
    [SerializeField] private float intervalDecayRate  = 0.12f;

    [Header("Gap Settings")]
    [SerializeField] private float minGapY  = -2.5f;
    [SerializeField] private float maxGapY  = 2.5f;
    [SerializeField] private float gapSize  = 3.0f;

    [Header("Moving Wall Chance")]
    [Range(0f, 1f)]
    [SerializeField] private float movingWallChance = 0.25f;

    // ─────────────────────────────────────────────────────────────────────────
    private float timer;

    private void Start()
    {
        timer = baseInterval * 1.2f; // grace period
    }

    private void Update()
    {
        if (GSGameManager.Instance == null || GSGameManager.Instance.IsGameOver) return;

        float spd = GSGameManager.Instance.CurrentSpeed;
        float interval = Mathf.Max(minInterval, baseInterval - spd * intervalDecayRate);

        timer -= Time.deltaTime;
        if (timer <= 0f)
        {
            SpawnObstacle();
            timer = interval;
        }
    }

    private void SpawnObstacle()
    {
        GameObject prefab = (Random.value < movingWallChance && movingWallPrefab != null)
            ? movingWallPrefab : wallPrefab;
        if (prefab == null) return;

        float gapY = Random.Range(minGapY, maxGapY);
        Vector3 pos = new Vector3(spawnX, 0f, 0f);
        GameObject go = Instantiate(prefab, pos, Quaternion.identity);

        // Initialize the wall with gap position
        GSWallSegment wall = go.GetComponent<GSWallSegment>();
        wall?.Initialize(gapY, gapSize);
    }
}
