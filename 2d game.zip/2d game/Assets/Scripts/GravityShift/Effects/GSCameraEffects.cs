using System.Collections;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// GRAVITY SHIFT: CORE ESCAPE — Camera Effects
/// ══════════════════════════════════════════════════════════════
/// Manages all camera-space effects:
///   • Screen shake (intensity ramps with game speed)
///   • Damage vignette flash (red for damage, purple for chaos)
///   • Glitch offset (chromatic aberration sim via UI layers)
///   • Gravity shift "punch" (brief shake on every gravity flip)
///
/// Uses unscaledDeltaTime so effects play during slow-motion & pause.
/// Singleton – callable from any system.
/// ══════════════════════════════════════════════════════════════
/// Attach to an empty "GSCameraEffects" GameObject.
/// </summary>
public class GSCameraEffects : MonoBehaviour
{
    // ─── Singleton ─────────────────────────────────────────────────────────────
    public static GSCameraEffects Instance { get; private set; }

    // ─── Shake ─────────────────────────────────────────────────────────────────
    [Header("Screen Shake")]
    [SerializeField] private float shootShakeIntensity   = 0.03f;
    [SerializeField] private float damageShakeIntensity  = 0.35f;
    [SerializeField] private float gravityShakeIntensity = 0.12f;
    [SerializeField] private float chaosShakeIntensity   = 0.22f;
    [SerializeField] private float shakeDecay            = 10f;

    private Transform  camTransform;
    private Vector3    camRestPos;
    private float      currentShake;

    // ─── Vignette ──────────────────────────────────────────────────────────────
    [Header("Vignette")]
    [SerializeField] private Image vignetteImage;
    [SerializeField] private float vignetteFadeSpeed = 5f;

    // ─── Glitch (UI layer offset sim) ──────────────────────────────────────────
    [Header("Glitch")]
    [Tooltip("A semi-transparent copy of the camera view tinted red/blue, offset for aberration.")]
    [SerializeField] private RectTransform glitchLayerR;
    [SerializeField] private RectTransform glitchLayerB;
    [SerializeField] private float glitchIntensity  = 8f;
    [SerializeField] private float glitchDuration   = 0.5f;

    // ─────────────────────────────────────────────────────────────────────────
    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;

        Camera cam = Camera.main;
        if (cam != null)
        {
            camTransform = cam.transform;
            camRestPos   = cam.transform.localPosition;
        }
    }

    private void Start()
    {
        if (vignetteImage != null) vignetteImage.color = new Color(0f, 0f, 0f, 0f);
        if (glitchLayerR  != null) glitchLayerR.anchoredPosition = Vector2.zero;
        if (glitchLayerB  != null) glitchLayerB.anchoredPosition = Vector2.zero;

        // Subscribe to gravity shifts
        if (GravitySystem.Instance != null)
            GravitySystem.Instance.OnGravityShifted += _ => Shake(gravityShakeIntensity);
    }

    private void Update()
    {
        UpdateShake();
        UpdateVignette();
    }

    // ─── Shake ─────────────────────────────────────────────────────────────────

    private void UpdateShake()
    {
        if (currentShake <= 0f || camTransform == null) return;
        camTransform.localPosition = camRestPos +
            (Vector3)(Random.insideUnitCircle * currentShake);
        currentShake -= shakeDecay * Time.unscaledDeltaTime;
        if (currentShake <= 0f)
        {
            currentShake = 0f;
            camTransform.localPosition = camRestPos;
        }
    }

    public void Shake(float intensity)
        => currentShake = Mathf.Max(currentShake, intensity);

    public void ShakeOnShoot()  => Shake(shootShakeIntensity);
    public void ShakeOnDamage() => Shake(damageShakeIntensity);
    public void ShakeOnChaos()  => Shake(chaosShakeIntensity);

    // ─── Vignette ──────────────────────────────────────────────────────────────

    private void UpdateVignette()
    {
        if (vignetteImage == null) return;
        Color c = vignetteImage.color;
        if (c.a > 0f)
        {
            c.a = Mathf.Max(0f, c.a - vignetteFadeSpeed * Time.unscaledDeltaTime);
            vignetteImage.color = c;
        }
    }

    public void FlashVignette(Color color)
    {
        if (vignetteImage == null) return;
        color.a = 0.55f;
        vignetteImage.color = color;
    }

    // ─── Glitch Effect ─────────────────────────────────────────────────────────

    public void TriggerGlitch()
    {
        StopCoroutine(nameof(GlitchRoutine));
        StartCoroutine(GlitchRoutine());
    }

    private IEnumerator GlitchRoutine()
    {
        float elapsed = 0f;
        while (elapsed < glitchDuration)
        {
            elapsed += Time.unscaledDeltaTime;

            // Random offset between frames for each color channel layer
            float rx = Random.Range(-glitchIntensity, glitchIntensity);
            float ry = Random.Range(-glitchIntensity * 0.3f, glitchIntensity * 0.3f);
            float bx = -rx * 0.7f;
            float by = -ry * 0.7f;

            if (glitchLayerR != null) glitchLayerR.anchoredPosition = new Vector2(rx, ry);
            if (glitchLayerB != null) glitchLayerB.anchoredPosition = new Vector2(bx, by);

            yield return null;
        }

        if (glitchLayerR != null) glitchLayerR.anchoredPosition = Vector2.zero;
        if (glitchLayerB != null) glitchLayerB.anchoredPosition = Vector2.zero;
    }
}
