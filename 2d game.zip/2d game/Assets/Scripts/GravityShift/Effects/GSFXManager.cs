using UnityEngine;
using System.Collections;
using System.Collections.Generic;

/// <summary>
/// GRAVITY SHIFT: CORE ESCAPE — FX Manager
/// ══════════════════════════════════════════════════════════════
/// Lightweight particle/effect manager with pooled burst particles.
/// Uses a simple manual pool so there are zero GC allocations
/// during gameplay.
///
/// Effects:
///   • HitEffect      — small cyan burst on projectile hit
///   • EnemyDeath     — neon explosion ring + sparks
///   • GravityShift   — brief directional swoosh
///   • HealthPickup   — green sparkle burst
/// ══════════════════════════════════════════════════════════════
/// Attach to an empty "GSFXManager" GameObject.
/// Assign all prefabs in the Inspector.
/// </summary>
public class GSFXManager : MonoBehaviour
{
    // ─── Singleton ─────────────────────────────────────────────────────────────
    public static GSFXManager Instance { get; private set; }

    // ─── Prefabs ───────────────────────────────────────────────────────────────
    [Header("Effect Prefabs")]
    [Tooltip("Small burst on projectile hit (auto-destroy in prefab).")]
    [SerializeField] private GameObject hitEffectPrefab;
    [Tooltip("Larger explosion ring for enemy death.")]
    [SerializeField] private GameObject enemyDeathEffectPrefab;
    [Tooltip("Green sparkle for health pickup.")]
    [SerializeField] private GameObject healthPickupEffectPrefab;
    [Tooltip("Gravity shift swoosh (directional).")]
    [SerializeField] private GameObject gravityShiftEffectPrefab;

    // ─── Pool ──────────────────────────────────────────────────────────────────
    [Header("Pool Sizes")]
    [SerializeField] private int hitPoolSize        = 10;
    [SerializeField] private int deathPoolSize      = 6;
    [SerializeField] private int healthFXPoolSize   = 4;

    private Queue<GameObject> hitPool        = new Queue<GameObject>();
    private Queue<GameObject> deathPool      = new Queue<GameObject>();
    private Queue<GameObject> healthFXPool   = new Queue<GameObject>();

    // ─────────────────────────────────────────────────────────────────────────
    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;

        PreWarm(hitEffectPrefab,        hitPoolSize,     hitPool);
        PreWarm(enemyDeathEffectPrefab, deathPoolSize,   deathPool);
        PreWarm(healthPickupEffectPrefab, healthFXPoolSize, healthFXPool);
    }

    private void PreWarm(GameObject prefab, int count, Queue<GameObject> pool)
    {
        if (prefab == null) return;
        for (int i = 0; i < count; i++)
        {
            GameObject go = Instantiate(prefab, transform);
            go.SetActive(false);
            pool.Enqueue(go);
        }
    }

    // ─── Public API ────────────────────────────────────────────────────────────

    public void PlayHitEffect(Vector3 pos)
        => PlayFromPool(hitPool, hitEffectPrefab, pos, 0.5f);

    public void PlayEnemyDeathEffect(Vector3 pos)
        => PlayFromPool(deathPool, enemyDeathEffectPrefab, pos, 1.0f);

    public void PlayHealthPickupEffect(Vector3 pos)
        => PlayFromPool(healthFXPool, healthPickupEffectPrefab, pos, 0.8f);

    public void PlayGravityShiftEffect(Vector3 pos, GravitySystem.GravityDir dir)
    {
        if (gravityShiftEffectPrefab == null) return;
        GameObject go = Instantiate(gravityShiftEffectPrefab, pos, GetRotationForDir(dir));
        Destroy(go, 1.0f);
    }

    // ─── Pool Logic ────────────────────────────────────────────────────────────

    private void PlayFromPool(Queue<GameObject> pool, GameObject prefab, Vector3 pos, float lifetime)
    {
        if (prefab == null) return;

        GameObject go;
        if (pool.Count > 0)
        {
            go = pool.Dequeue();
        }
        else
        {
            go = Instantiate(prefab, transform);
        }

        go.transform.position = pos;
        go.SetActive(true);
        StartCoroutine(ReturnToPool(go, pool, lifetime));
    }

    private IEnumerator ReturnToPool(GameObject go, Queue<GameObject> pool, float delay)
    {
        yield return new WaitForSeconds(delay);
        if (go != null)
        {
            go.SetActive(false);
            pool.Enqueue(go);
        }
    }

    // ─── Helpers ───────────────────────────────────────────────────────────────

    private static Quaternion GetRotationForDir(GravitySystem.GravityDir dir)
    {
        float angle = dir switch
        {
            GravitySystem.GravityDir.Up    => 0f,
            GravitySystem.GravityDir.Down  => 180f,
            GravitySystem.GravityDir.Left  => 90f,
            GravitySystem.GravityDir.Right => -90f,
            _ => 0f
        };
        return Quaternion.Euler(0f, 0f, angle);
    }
}
