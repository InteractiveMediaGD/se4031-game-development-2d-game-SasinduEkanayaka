using UnityEngine;

/// <summary>
/// GRAVITY SHIFT: CORE ESCAPE — Core Rotator
/// ══════════════════════════════════════════════════════════════
/// Rotates the background "core ring" sprite continuously.
/// Speed increases with game difficulty, and DRAMATICALLY
/// accelerates during Chaos Mode for visual intensity.
///
/// Also spawns floating ambient particles to enhance depth.
/// ══════════════════════════════════════════════════════════════
/// Attach to the CoreRing or Background sprite GameObject.
/// </summary>
public class GSCoreRotator : MonoBehaviour
{
    [Header("Rotation")]
    [Tooltip("Base rotation speed in degrees per second.")]
    [SerializeField] private float baseRotationSpeed = 12f;
    [Tooltip("Speed multiplier applied to game speed for dynamic rotation.")]
    [SerializeField] private float speedScaleMultiplier = 2f;
    [Tooltip("Chaos Mode rotation speed (much faster).")]
    [SerializeField] private float chaosRotationSpeed = 180f;
    [Tooltip("How fast the rotation transitions between normal and chaos speeds.")]
    [SerializeField] private float rotationLerpSpeed = 3f;

    [Header("Pulse Scale")]
    [Tooltip("Whether the core ring pulses in scale slightly.")]
    [SerializeField] private bool  enablePulse    = true;
    [SerializeField] private float pulseSpeed     = 0.8f;
    [SerializeField] private float pulseAmplitude = 0.03f;

    // ─── Private State ─────────────────────────────────────────────────────────
    private float  targetRotationSpeed;
    private float  currentRotationSpeed;
    private bool   chaosMode;
    private float  pulseTimer;
    private Vector3 baseScale;

    // ─────────────────────────────────────────────────────────────────────────
    private void Start()
    {
        baseScale            = transform.localScale;
        currentRotationSpeed = baseRotationSpeed;
        targetRotationSpeed  = baseRotationSpeed;
    }

    private void Update()
    {
        // Target speed based on mode
        if (!chaosMode && GSGameManager.Instance != null)
        {
            float gameSpeed  = GSGameManager.Instance.CurrentSpeed;
            targetRotationSpeed = baseRotationSpeed + gameSpeed * speedScaleMultiplier;
        }

        // Smooth speed transition
        currentRotationSpeed = Mathf.Lerp(currentRotationSpeed, targetRotationSpeed,
                                           Time.deltaTime * rotationLerpSpeed);

        // Rotate
        transform.Rotate(0f, 0f, currentRotationSpeed * Time.deltaTime);

        // Pulse scale
        if (enablePulse)
        {
            pulseTimer += Time.deltaTime * pulseSpeed;
            float scale = 1f + Mathf.Sin(pulseTimer) * pulseAmplitude;
            transform.localScale = baseScale * scale;
        }
    }

    /// <summary>Switch chaos mode on/off (called by GravityChaosModeController).</summary>
    public void SetChaosMode(bool active)
    {
        chaosMode           = active;
        targetRotationSpeed = active ? chaosRotationSpeed : baseRotationSpeed;
    }
}
