using UnityEngine;

/// <summary>
/// GRAVITY SHIFT: CORE ESCAPE — Player Shooter
/// ══════════════════════════════════════════════════════════════
/// Left click fires a projectile toward the mouse cursor.
/// Hold to auto-fire at the set fire rate.
///
/// Projectile color and scale scale up during Chaos Mode
/// for visual feedback and as a bonus mechanic.
/// ══════════════════════════════════════════════════════════════
/// Attach to the Player GameObject.
/// </summary>
public class GSShooter : MonoBehaviour
{
    [Header("Projectile")]
    [SerializeField] private GameObject projectilePrefab;
    [SerializeField] private Transform  firePoint;

    [Header("Fire Rate")]
    [Tooltip("Seconds between shots (hold mouse to auto-fire).")]
    [SerializeField] private float fireRate = 0.22f;

    [Header("Chaos Mode Boost")]
    [SerializeField] private Color normalShotColor = new Color(0.3f, 0.7f, 1f);
    [SerializeField] private Color chaosShotColor  = new Color(1f, 0.2f, 1f);
    [SerializeField] private float chaosScaleBoost = 1.5f;

    private float nextFireTime;
    private Camera mainCamera;

    private void Start()
    {
        mainCamera = Camera.main;

        if (firePoint == null)
        {
            var fp = new GameObject("GS_FirePoint");
            fp.transform.SetParent(transform);
            fp.transform.localPosition = new Vector3(0f, 0.5f, 0f);
            firePoint = fp.transform;
        }
    }

    private void Update()
    {
        if (GSGameManager.Instance == null || GSGameManager.Instance.IsGameOver) return;
        if (GravitySystem.Instance != null && GravitySystem.Instance.ChaosActive &&
            Random.value < 0.1f) return; // chaos slightly disrupts firing

        if (Input.GetMouseButton(0) && Time.time >= nextFireTime)
            Fire();
    }

    private void Fire()
    {
        if (projectilePrefab == null) return;

        nextFireTime = Time.time + fireRate;

        // Direction toward mouse in world space
        Vector3 mouseWorld = mainCamera.ScreenToWorldPoint(Input.mousePosition);
        mouseWorld.z = 0f;
        Vector2 dir = ((Vector2)mouseWorld - (Vector2)firePoint.position).normalized;

        GameObject projGO = Instantiate(projectilePrefab, firePoint.position, Quaternion.identity);

        // Rotate to face direction
        float angle = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg;
        projGO.transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);

        // Pass direction
        projGO.GetComponent<GSProjectile>()?.SetDirection(dir);

        // Chaos Mode visual boost
        bool inChaos = GravitySystem.Instance != null && GravitySystem.Instance.ChaosActive;
        SpriteRenderer sr = projGO.GetComponent<SpriteRenderer>();
        if (sr != null) sr.color = inChaos ? chaosShotColor : normalShotColor;
        if (inChaos) projGO.transform.localScale *= chaosScaleBoost;

        // Subtle shake
        GSCameraEffects.Instance?.ShakeOnShoot();
    }
}
