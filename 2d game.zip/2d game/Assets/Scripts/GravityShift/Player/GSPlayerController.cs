using System.Collections;
using UnityEngine;

/// <summary>
/// GRAVITY SHIFT: CORE ESCAPE — Player Controller
/// ══════════════════════════════════════════════════════════════
/// The player is a physics-driven object inside the rotating core.
/// The GravitySystem changes Physics2D.gravity direction, so the
/// player naturally "falls" toward whichever wall is the current floor.
///
/// Player input movement:
///   The two axes perpendicular to the current gravity direction allow
///   the player to strafe — movement is always relative to the current
///   gravity's tangent plane.
///
/// Example: gravity pulling LEFT → player moves UP/DOWN on screen.
///
/// Additional features:
///   • Invincibility frames after taking damage (sprite flash)
///   • Boundary clamping so player stays within the core
///   • Smooth visual rotation to align sprite with gravity
/// ══════════════════════════════════════════════════════════════
/// Attach to the Player prefab (requires Rigidbody2D).
/// </summary>
[RequireComponent(typeof(Rigidbody2D))]
public class GSPlayerController : MonoBehaviour
{
    // ─── Movement ──────────────────────────────────────────────────────────────
    [Header("Movement")]
    [Tooltip("Lateral speed (perpendicular to gravity).")]
    [SerializeField] private float moveSpeed = 5.5f;
    [Tooltip("Screen boundary half-extents. Player clamped within these.")]
    [SerializeField] private float boundaryX = 8f;
    [SerializeField] private float boundaryY = 5f;

    // ─── Visual Rotation ───────────────────────────────────────────────────────
    [Header("Visual")]
    [Tooltip("How quickly the sprite rotates to align with gravity.")]
    [SerializeField] private float rotationSpeed = 720f; // degrees/second

    // ─── Damage & I-frames ─────────────────────────────────────────────────────
    [Header("Damage")]
    [SerializeField] private int   obstacleDamage    = 20;
    [SerializeField] private int   enemyContactDamage = 25;
    [SerializeField] private float iframeDuration    = 1.2f;
    [SerializeField] private float flashInterval     = 0.1f;

    // ─── Private State ─────────────────────────────────────────────────────────
    private Rigidbody2D  rb;
    private SpriteRenderer sr;
    private bool         isInvincible;

    // Target rotation angle based on gravity direction
    private float targetAngle;

    // ─────────────────────────────────────────────────────────────────────────
    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        sr = GetComponent<SpriteRenderer>();
    }

    private void OnEnable()
    {
        if (GravitySystem.Instance != null)
            GravitySystem.Instance.OnGravityShifted += OnGravityChanged;
    }

    private void OnDisable()
    {
        if (GravitySystem.Instance != null)
            GravitySystem.Instance.OnGravityShifted -= OnGravityChanged;
    }

    private void Start()
    {
        // Set initial gravity-alignment angle
        OnGravityChanged(GravitySystem.Instance != null
            ? GravitySystem.Instance.CurrentDirection
            : GravitySystem.GravityDir.Down);
    }

    private void Update()
    {
        if (GSGameManager.Instance != null && GSGameManager.Instance.IsGameOver)
        {
            rb.velocity = Vector2.zero;
            return;
        }

        HandleLateralMovement();
        RotateSprite();
        ClampPosition();
    }

    // ─── Lateral Movement ──────────────────────────────────────────────────────

    private void HandleLateralMovement()
    {
        // Horizontal input (positive = right)
        float h = Input.GetAxisRaw("Horizontal") == 0
            ? (Input.GetKey(KeyCode.RightArrow) ? 1f : Input.GetKey(KeyCode.LeftArrow) ? -1f : 0f)
            : 0f; // WASD is captured by GravitySystem; use arrow keys here
        // Actually for movement we use Q/E or second set of keys, or auto-movement
        // Let's use Q/E for strafing to avoid conflict with WASD gravity shift
        float lateral  = 0f;
        float vertical = 0f;

        if (Input.GetKey(KeyCode.Q)) lateral = -1f;
        else if (Input.GetKey(KeyCode.E)) lateral = 1f;

        if (Input.GetKey(KeyCode.Z)) vertical = -1f;
        else if (Input.GetKey(KeyCode.X)) vertical = 1f;

        // Map lateral/vertical to screen axes based on current gravity
        Vector2 moveDir = GetMoveDirection(lateral, vertical);
        rb.velocity = new Vector2(
            moveDir.x != 0 ? moveDir.x * moveSpeed : rb.velocity.x,
            moveDir.y != 0 ? moveDir.y * moveSpeed : rb.velocity.y
        );
    }

    /// <summary>
    /// Maps the player's 2D strafe input to world-space movement based
    /// on the current gravity direction.
    ///
    ///  GravityDir | Lateral input moves in X | Vertical input moves in Y
    ///  ---------- | ----------------------- | -------------------------
    ///  Down / Up  | X axis (left/right)     | Y axis (auto-fall)
    ///  Left/Right | Y axis (up/down)        | X axis (auto-fall)
    /// </summary>
    private Vector2 GetMoveDirection(float lat, float vert)
    {
        GravitySystem.GravityDir dir = GravitySystem.Instance != null
            ? GravitySystem.Instance.CurrentDirection
            : GravitySystem.GravityDir.Down;

        switch (dir)
        {
            case GravitySystem.GravityDir.Down:
            case GravitySystem.GravityDir.Up:
                return new Vector2(lat, vert);
            case GravitySystem.GravityDir.Left:
            case GravitySystem.GravityDir.Right:
                return new Vector2(vert, lat);
            default:
                return Vector2.zero;
        }
    }

    // ─── Visual Rotation ───────────────────────────────────────────────────────

    private void OnGravityChanged(GravitySystem.GravityDir dir)
    {
        switch (dir)
        {
            case GravitySystem.GravityDir.Down:  targetAngle =    0f; break;
            case GravitySystem.GravityDir.Up:    targetAngle =  180f; break;
            case GravitySystem.GravityDir.Left:  targetAngle =  -90f; break;
            case GravitySystem.GravityDir.Right: targetAngle =   90f; break;
        }
    }

    private void RotateSprite()
    {
        float current = transform.eulerAngles.z;
        float next    = Mathf.MoveTowardsAngle(current, targetAngle, rotationSpeed * Time.deltaTime);
        transform.rotation = Quaternion.Euler(0f, 0f, next);
    }

    // ─── Boundary Clamping ─────────────────────────────────────────────────────

    private void ClampPosition()
    {
        Vector3 p = transform.position;
        p.x = Mathf.Clamp(p.x, -boundaryX, boundaryX);
        p.y = Mathf.Clamp(p.y, -boundaryY, boundaryY);
        transform.position = p;

        // Kill velocity along a clamped axis to prevent jitter
        if (Mathf.Abs(transform.position.x) >= boundaryX)
            rb.velocity = new Vector2(0f, rb.velocity.y);
        if (Mathf.Abs(transform.position.y) >= boundaryY)
            rb.velocity = new Vector2(rb.velocity.x, 0f);
    }

    // ─── Collision ─────────────────────────────────────────────────────────────

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (isInvincible) return;
        if (GSGameManager.Instance == null || GSGameManager.Instance.IsGameOver) return;

        if (other.CompareTag("GSObstacle"))
        {
            GSGameManager.Instance.TakeDamage(obstacleDamage);
            GSCameraEffects.Instance?.ShakeOnDamage();
            GSCameraEffects.Instance?.FlashVignette(Color.red);
            StartCoroutine(IFrameRoutine());
        }
        else if (other.CompareTag("GSEnemy"))
        {
            GSGameManager.Instance.TakeDamage(enemyContactDamage);
            GSCameraEffects.Instance?.ShakeOnDamage();
            GSCameraEffects.Instance?.FlashVignette(Color.red);
            StartCoroutine(IFrameRoutine());

            GSEnemy e = other.GetComponent<GSEnemy>();
            e?.DestroyEnemy(awardScore: false);
        }
    }

    // ─── I-frames ──────────────────────────────────────────────────────────────

    private IEnumerator IFrameRoutine()
    {
        isInvincible = true;
        float elapsed = 0f;
        while (elapsed < iframeDuration)
        {
            if (sr != null)
            {
                bool flash = (elapsed % (flashInterval * 2f)) < flashInterval;
                sr.color = flash ? new Color(1f, 0.3f, 0.3f) : new Color(1f, 1f, 1f, 0.4f);
            }
            yield return new WaitForSeconds(flashInterval);
            elapsed += flashInterval;
        }
        if (sr != null) sr.color = Color.white;
        isInvincible = false;
    }
}
