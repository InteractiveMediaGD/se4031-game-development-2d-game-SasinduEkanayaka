using UnityEngine;

/// <summary>
/// GRAVITY SHIFT: CORE ESCAPE — Health Pack (Energy Orb)
/// ══════════════════════════════════════════════════════════════
/// Floats in place with a gentle pulse animation.
/// Heals the player on contact. Auto-destroys after a set time
/// so it doesn't clutter the arena.
///
/// The orb DOES respond to gravity (gravity scale > 0) so it
/// gently drifts toward the current gravity wall — making it
/// more interesting to collect as gravity shifts.
/// ══════════════════════════════════════════════════════════════
/// Tag: "GSHealthPack". CircleCollider2D (isTrigger).
/// </summary>
[RequireComponent(typeof(Rigidbody2D))]
public class GSHealthPack : MonoBehaviour
{
    [Header("Healing")]
    [SerializeField] private int healAmount = 30;

    [Header("Lifetime")]
    [Tooltip("Seconds before auto-destroy (prevents arena clutter).")]
    [SerializeField] private float lifetime = 10f;

    [Header("Pulse Animation")]
    [SerializeField] private float pulseSpeed     = 2.5f;
    [SerializeField] private float pulseScaleMin  = 0.85f;
    [SerializeField] private float pulseScaleMax  = 1.15f;

    [Header("Effects")]
    [SerializeField] private GameObject pickupFXPrefab;

    private Rigidbody2D rb;
    private float       birthTime;
    private Vector3     baseScale;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        rb.gravityScale = 0.12f; // gently drifts with gravity
        rb.drag         = 0.8f;
        baseScale       = transform.localScale;
    }

    private void Start()
    {
        birthTime = Time.time;
        Destroy(gameObject, lifetime);
    }

    private void Update()
    {
        // Pulse scale animation
        float t     = (Mathf.Sin((Time.time - birthTime) * pulseSpeed) + 1f) * 0.5f;
        float scale = Mathf.Lerp(pulseScaleMin, pulseScaleMax, t);
        transform.localScale = baseScale * scale;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (!other.CompareTag("GSPlayer")) return;

        GSGameManager.Instance?.Heal(healAmount);
        GSUIManager.Instance?.SpawnHealPopup(healAmount, transform.position);

        if (pickupFXPrefab != null)
            Instantiate(pickupFXPrefab, transform.position, Quaternion.identity);

        Destroy(gameObject);
    }
}
