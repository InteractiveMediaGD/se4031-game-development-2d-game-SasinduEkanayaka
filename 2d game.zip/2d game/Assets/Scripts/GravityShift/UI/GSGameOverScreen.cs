using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

/// <summary>
/// GRAVITY SHIFT: CORE ESCAPE — Game Over Screen
/// ══════════════════════════════════════════════════════════════
/// Animated game-over panel:
///   1. Blur/darken overlay fades in
///   2. "CORE FAILED" title glitches in (chromatic aberration feel)
///   3. Final score counts up
///   4. Buttons appear from below
///
/// Uses Time.unscaledDeltaTime throughout so all animations work
/// even while Time.timeScale = 0.
/// ══════════════════════════════════════════════════════════════
/// Attach to the GameOverPanel GameObject.
/// </summary>
public class GSGameOverScreen : MonoBehaviour
{
    // ─── UI References ─────────────────────────────────────────────────────────
    [Header("Overlay")]
    [SerializeField] private Image overlay;
    [SerializeField] private float overlayAlpha      = 0.88f;
    [SerializeField] private float overlayDuration   = 0.45f;

    [Header("Title")]
    [SerializeField] private RectTransform titleRT;
    [SerializeField] private CanvasGroup   titleGroup;
    [SerializeField] private TextMeshProUGUI titleText;
    [SerializeField] private float titleSlideDist    = 60f;
    [SerializeField] private float titleDuration     = 0.6f;

    [Header("Score")]
    [SerializeField] private TextMeshProUGUI finalScoreValue;
    [SerializeField] private TextMeshProUGUI highScoreValue;
    [SerializeField] private float scoreRollDuration  = 1.2f;

    [Header("Buttons")]
    [SerializeField] private CanvasGroup   buttonsGroup;
    [SerializeField] private RectTransform buttonsRT;
    [SerializeField] private float buttonsSlideDist   = 50f;
    [SerializeField] private float buttonsDuration    = 0.5f;

    [Header("Glitch")]
    [Tooltip("Number of glitch flickers on 'CORE FAILED' title entrance.")]
    [SerializeField] private int   glitchCount        = 5;
    [SerializeField] private float glitchInterval     = 0.07f;

    // ─── Cached positions ──────────────────────────────────────────────────────
    private Vector2 titleRestPos;
    private Vector2 buttonsRestPos;

    // ─────────────────────────────────────────────────────────────────────────
    private void Awake()
    {
        if (titleRT   != null) titleRestPos   = titleRT.anchoredPosition;
        if (buttonsRT != null) buttonsRestPos = buttonsRT.anchoredPosition;
    }

    private void OnEnable()
    {
        int score = GSGameManager.Instance != null ? GSGameManager.Instance.CurrentScore : 0;
        int hs    = GSGameManager.Instance != null ? GSGameManager.Instance.HighScore    : 0;
        StartCoroutine(Sequence(score, hs));
    }

    // ─── Main Sequence ─────────────────────────────────────────────────────────

    private IEnumerator Sequence(int finalScore, int highScore)
    {
        // ── Reset ──────────────────────────────────────────────────────────────
        SetOverlayAlpha(0f);
        if (titleGroup   != null) titleGroup.alpha   = 0f;
        if (buttonsGroup != null) { buttonsGroup.alpha = 0f; buttonsGroup.interactable = false; buttonsGroup.blocksRaycasts = false; }
        if (titleRT      != null) titleRT.anchoredPosition   = titleRestPos   + Vector2.up * titleSlideDist;
        if (buttonsRT    != null) buttonsRT.anchoredPosition = buttonsRestPos - Vector2.up * buttonsSlideDist;
        if (finalScoreValue != null) finalScoreValue.text = "000000";
        if (highScoreValue  != null) highScoreValue.text  = $"BEST: {highScore:D6}";

        // ── Step 1: Overlay ────────────────────────────────────────────────────
        yield return StartCoroutine(FadeOverlay(overlayDuration));

        // ── Step 2: Title glitch entrance ─────────────────────────────────────
        yield return StartCoroutine(GlitchTitleIn());

        yield return new WaitForSecondsRealtime(0.15f);

        // ── Step 3: Score roll ─────────────────────────────────────────────────
        yield return StartCoroutine(RollScore(finalScore));

        yield return new WaitForSecondsRealtime(0.2f);

        // ── Step 4: Buttons slide in ───────────────────────────────────────────
        yield return StartCoroutine(SlideInButtons());
    }

    // ─── Sub-Animations ────────────────────────────────────────────────────────

    private IEnumerator FadeOverlay(float duration)
    {
        float e = 0f;
        while (e < duration)
        {
            e += Time.unscaledDeltaTime;
            SetOverlayAlpha(Mathf.Lerp(0f, overlayAlpha, e / duration));
            yield return null;
        }
        SetOverlayAlpha(overlayAlpha);
    }

    private IEnumerator GlitchTitleIn()
    {
        // Rapid flicker effect — title flashes in and out quickly
        for (int i = 0; i < glitchCount; i++)
        {
            if (titleGroup != null) titleGroup.alpha = (i % 2 == 0) ? 1f : 0f;
            if (titleText  != null) titleText.color  = (i % 2 == 0)
                ? new Color(1f, 0.2f, 0.3f)
                : new Color(0.5f, 0f, 1f);
            yield return new WaitForSecondsRealtime(glitchInterval);
        }

        // Final stable state: slide down + fade in
        float elapsed  = 0f;
        Vector2 startP = titleRestPos + Vector2.up * titleSlideDist;
        if (titleGroup != null) titleGroup.alpha = 1f;
        if (titleText  != null) titleText.color  = new Color(1f, 0.2f, 0.3f);

        while (elapsed < titleDuration)
        {
            elapsed += Time.unscaledDeltaTime;
            float te = EaseOutBack(Mathf.Clamp01(elapsed / titleDuration));
            if (titleRT != null)
                titleRT.anchoredPosition = Vector2.Lerp(startP, titleRestPos, te);
            yield return null;
        }
        if (titleRT != null) titleRT.anchoredPosition = titleRestPos;
    }

    private IEnumerator RollScore(int target)
    {
        if (finalScoreValue == null) yield break;
        float elapsed = 0f;
        while (elapsed < scoreRollDuration)
        {
            elapsed += Time.unscaledDeltaTime;
            int shown = Mathf.RoundToInt(Mathf.Lerp(0, target,
                        EaseOutCubic(Mathf.Clamp01(elapsed / scoreRollDuration))));
            finalScoreValue.text = shown.ToString("D6");
            yield return null;
        }
        finalScoreValue.text = target.ToString("D6");
    }

    private IEnumerator SlideInButtons()
    {
        float elapsed    = 0f;
        Vector2 startPos = buttonsRestPos - Vector2.up * buttonsSlideDist;
        if (buttonsGroup != null) buttonsGroup.alpha = 0f;

        while (elapsed < buttonsDuration)
        {
            elapsed  += Time.unscaledDeltaTime;
            float te  = EaseOutCubic(Mathf.Clamp01(elapsed / buttonsDuration));
            if (buttonsGroup != null) buttonsGroup.alpha = te;
            if (buttonsRT   != null) buttonsRT.anchoredPosition = Vector2.Lerp(startPos, buttonsRestPos, te);
            yield return null;
        }
        if (buttonsGroup != null) { buttonsGroup.alpha = 1f; buttonsGroup.interactable = true; buttonsGroup.blocksRaycasts = true; }
        if (buttonsRT   != null) buttonsRT.anchoredPosition = buttonsRestPos;
    }

    // ─── Button Callbacks ──────────────────────────────────────────────────────

    public void OnRestartClicked()
    {
        Time.timeScale = 1f;
        UnityEngine.SceneManagement.SceneManager.LoadScene(
            UnityEngine.SceneManagement.SceneManager.GetActiveScene().buildIndex);
    }

    public void OnMainMenuClicked()
    {
        Time.timeScale = 1f;
        UnityEngine.SceneManagement.SceneManager.LoadScene("GS_MainMenu");
    }

    // ─── Helpers ───────────────────────────────────────────────────────────────

    private void SetOverlayAlpha(float a)
    {
        if (overlay != null)
            overlay.color = new Color(0.02f, 0f, 0.08f, a);
    }

    private static float EaseOutCubic(float t) => 1f - Mathf.Pow(1f - t, 3f);

    private static float EaseOutBack(float t)
    {
        const float c1 = 1.70158f;
        const float c3 = c1 + 1f;
        float tm1 = t - 1f;
        return 1f + c3 * tm1 * tm1 * tm1 + c1 * tm1 * tm1;
    }
}
