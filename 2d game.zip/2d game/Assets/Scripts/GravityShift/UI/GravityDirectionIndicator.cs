using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

/// <summary>
/// GRAVITY SHIFT: CORE ESCAPE — Gravity Direction Indicator
/// ══════════════════════════════════════════════════════════════
/// A HUD element showing the current gravity direction with:
///   • A compass-style ring
///   • An arrow that smoothly rotates to the active direction
///   • 4 small directional dots (light up when active)
///   • Color shifts per direction for instant readability
///   • A brief "punch" scale animation on every direction change
///
/// Position: center-bottom of the screen.
/// ══════════════════════════════════════════════════════════════
/// Attach to the GravityIndicator container.
/// </summary>
public class GravityDirectionIndicator : MonoBehaviour
{
    [Header("Arrow")]
    [Tooltip("The arrow RectTransform that rotates.")]
    [SerializeField] private RectTransform arrowTransform;
    [SerializeField] private Image         arrowImage;

    [Header("Directional Dots")]
    [Tooltip("4 dots in order: Down, Up, Left, Right")]
    [SerializeField] private Image[] directionDots = new Image[4];
    [SerializeField] private Color  dotActiveColor  = Color.white;
    [SerializeField] private Color  dotInactiveColor = new Color(1f, 1f, 1f, 0.2f);

    [Header("Background Panel")]
    [SerializeField] private Image panelBackground;

    [Header("Label")]
    [SerializeField] private TextMeshProUGUI directionLabel;

    [Header("Animation")]
    [SerializeField] private float rotateDuration = 0.25f;
    [SerializeField] private float punchScale     = 1.3f;
    [SerializeField] private float punchDuration  = 0.15f;

    // Arrow angles per direction (in Z euler degrees)
    // Assuming arrow sprite points UP by default (0°)
    private static readonly float[] TargetAngles = { 180f, 0f, 90f, -90f }; // Down, Up, Left, Right
    private static readonly Color[] DirColors    =
    {
        new Color(0.00f, 0.55f, 1.00f), // Down  – blue
        new Color(0.65f, 0.00f, 1.00f), // Up    – violet
        new Color(0.00f, 0.90f, 0.65f), // Left  – teal
        new Color(1.00f, 0.45f, 0.00f), // Right – orange
    };
    private static readonly string[] Labels = { "GRAVITY: DOWN", "GRAVITY: UP", "GRAVITY: LEFT", "GRAVITY: RIGHT" };

    // ─────────────────────────────────────────────────────────────────────────
    private void OnEnable()
    {
        if (GravitySystem.Instance != null)
            GravitySystem.Instance.OnGravityShifted += OnGravityShifted;
    }

    private void OnDisable()
    {
        if (GravitySystem.Instance != null)
            GravitySystem.Instance.OnGravityShifted -= OnGravityShifted;
    }

    private void Start()
    {
        // Init to current direction
        GravitySystem.GravityDir startDir = GravitySystem.Instance != null
            ? GravitySystem.Instance.CurrentDirection
            : GravitySystem.GravityDir.Down;
        OnGravityShifted(startDir);
    }

    // ─────────────────────────────────────────────────────────────────────────

    private void OnGravityShifted(GravitySystem.GravityDir dir)
    {
        int idx = (int)dir;

        StopAllCoroutines();
        StartCoroutine(RotateArrow(TargetAngles[idx]));
        StartCoroutine(PunchScale());
        StartCoroutine(AnimatePanelColor(DirColors[idx]));

        // Update dots
        for (int i = 0; i < directionDots.Length; i++)
        {
            if (directionDots[i] == null) continue;
            directionDots[i].color = (i == idx) ? dotActiveColor : dotInactiveColor;
        }

        // Update label
        if (directionLabel != null)
            directionLabel.text = Labels[idx];

        // Arrow tint
        if (arrowImage != null)
            arrowImage.color = DirColors[idx];
    }

    // ─── Animations ────────────────────────────────────────────────────────────

    private IEnumerator RotateArrow(float targetAngle)
    {
        if (arrowTransform == null) yield break;
        float elapsed = 0f;
        float startAngle = arrowTransform.localEulerAngles.z;
        while (elapsed < rotateDuration)
        {
            elapsed += Time.unscaledDeltaTime;
            float t  = Mathf.SmoothStep(0f, 1f, elapsed / rotateDuration);
            float a  = Mathf.LerpAngle(startAngle, targetAngle, t);
            arrowTransform.localEulerAngles = new Vector3(0f, 0f, a);
            yield return null;
        }
        arrowTransform.localEulerAngles = new Vector3(0f, 0f, targetAngle);
    }

    private IEnumerator PunchScale()
    {
        if (arrowTransform == null) yield break;
        float elapsed = 0f;
        while (elapsed < punchDuration)
        {
            elapsed += Time.unscaledDeltaTime;
            float t  = elapsed / punchDuration;
            // Scale up then back: reaches peak at 50%
            float curve = Mathf.Sin(t * Mathf.PI);
            float scale = 1f + (punchScale - 1f) * curve;
            arrowTransform.localScale = Vector3.one * scale;
            yield return null;
        }
        arrowTransform.localScale = Vector3.one;
    }

    private IEnumerator AnimatePanelColor(Color target)
    {
        if (panelBackground == null) yield break;
        float elapsed = 0f;
        Color start   = panelBackground.color;
        target.a      = start.a; // preserve panel alpha
        while (elapsed < rotateDuration)
        {
            elapsed += Time.unscaledDeltaTime;
            panelBackground.color = Color.Lerp(start, target, elapsed / rotateDuration);
            yield return null;
        }
        panelBackground.color = target;
    }
}
