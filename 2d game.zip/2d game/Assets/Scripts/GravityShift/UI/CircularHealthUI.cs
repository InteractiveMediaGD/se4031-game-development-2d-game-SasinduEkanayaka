using UnityEngine;
using UnityEngine.UI;
using TMPro;

/// <summary>
/// GRAVITY SHIFT: CORE ESCAPE — Circular Health Ring UI
/// ══════════════════════════════════════════════════════════════
/// A dedicated component for the health ring that manages:
///   • Background ring (always full circle, dim)
///   • Fill ring (radial 360, animates to health %)
///   • Color gradient driven by health level
///   • Pulse animation when health is critically low (≤ 25%)
///   • "LOW HEALTH" warning label
///
/// The ring uses TWO Image components stacked:
///   1. HealthRingBG  – full circle, dark version of color
///   2. HealthRingFill – same size, filled Radial360, bright color
///
/// Wire this component to the parent RectTransform of both images.
/// ══════════════════════════════════════════════════════════════
/// Attach to the HealthRing container RectTransform.
/// </summary>
public class CircularHealthUI : MonoBehaviour
{
    [Header("Ring Images")]
    [Tooltip("The filled Radial360 Image — this animates with health.")]
    [SerializeField] private Image fillRing;
    [Tooltip("Background ring — always full, dark color.")]
    [SerializeField] private Image bgRing;

    [Header("Label")]
    [SerializeField] private TextMeshProUGUI healthNumericLabel;
    [SerializeField] private TextMeshProUGUI lowHealthWarning;

    [Header("Color Gradient")]
    [Tooltip("Gradient from left (0% health = red) to right (100% = green).")]
    [SerializeField] private Gradient colorGradient;

    [Header("Animation")]
    [Tooltip("Speed at which fill animates toward target.")]
    [SerializeField] private float fillSmoothSpeed = 5f;
    [Tooltip("Health % (0-1) threshold for critical pulse.")]
    [SerializeField] private float criticalThreshold = 0.25f;
    [SerializeField] private float criticalPulseSpeed = 4f;

    [Header("Background Ring Dimness")]
    [Range(0f, 1f)]
    [SerializeField] private float bgAlpha = 0.25f;

    // ─── Runtime ───────────────────────────────────────────────────────────────
    private float fillTarget  = 1f;
    private float fillCurrent = 1f;
    private float pulseTimer;

    // ─────────────────────────────────────────────────────────────────────────
    private void Start()
    {
        // Subscribe to health events
        if (GSGameManager.Instance != null)
            GSGameManager.Instance.OnHealthChanged += UpdateHealth;

        // Setup fill image
        if (fillRing != null)
        {
            fillRing.type       = Image.Type.Filled;
            fillRing.fillMethod = Image.FillMethod.Radial360;
            fillRing.fillOrigin = (int)Image.Origin360.Top; // fills from top, clockwise
            fillRing.fillAmount = 1f;
        }

        if (lowHealthWarning != null) lowHealthWarning.gameObject.SetActive(false);
        UpdateHealth(100, 100);
    }

    private void OnDestroy()
    {
        if (GSGameManager.Instance != null)
            GSGameManager.Instance.OnHealthChanged -= UpdateHealth;
    }

    private void Update()
    {
        // Smooth fill animation
        fillCurrent = Mathf.Lerp(fillCurrent, fillTarget, Time.deltaTime * fillSmoothSpeed);
        if (fillRing != null) fillRing.fillAmount = fillCurrent;

        // Critical pulse
        bool isCritical = fillTarget <= criticalThreshold;

        if (lowHealthWarning != null) lowHealthWarning.gameObject.SetActive(isCritical);

        if (isCritical && fillRing != null)
        {
            pulseTimer += Time.deltaTime * criticalPulseSpeed;
            float t = (Mathf.Sin(pulseTimer) + 1f) * 0.5f;
            fillRing.color = Color.Lerp(
                new Color(1f, 0.1f, 0.1f),
                new Color(1f, 0.6f, 0.1f),
                t
            );
        }
        else if (!isCritical && fillRing != null)
        {
            // Normal gradient color
            fillRing.color = colorGradient.Evaluate(fillCurrent);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────

    private void UpdateHealth(int current, int max)
    {
        fillTarget = max > 0 ? (float)current / max : 0f;

        if (healthNumericLabel != null)
            healthNumericLabel.text = current.ToString();

        // Set background ring color (dim version of current health color)
        if (bgRing != null)
        {
            Color c = colorGradient.Evaluate(fillTarget);
            c.a = bgAlpha;
            bgRing.color = c;
        }
    }
}
