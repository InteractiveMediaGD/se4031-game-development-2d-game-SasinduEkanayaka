using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

/// <summary>
/// GRAVITY SHIFT: CORE ESCAPE — UI Manager
/// ══════════════════════════════════════════════════════════════
/// Owns every in-game UI element. Subscribes to GSGameManager and
/// GravitySystem events — never polls in Update.
///
/// Manages:
///   • Circular Health Ring (filled Image, radial 360°)
///   • Score text (top right)
///   • Gravity Direction Indicator (arrow rotates)
///   • Ability Cooldown bar (bottom)
///   • Chaos Mode label (center pulse)
///   • Game Over panel (activates GSGameOverScreen)
///   • Floating heal popups
/// ══════════════════════════════════════════════════════════════
/// Attach to an empty "GSUIManager" child of the Canvas.
/// </summary>
public class GSUIManager : MonoBehaviour
{
    // ─── Singleton ─────────────────────────────────────────────────────────────
    public static GSUIManager Instance { get; private set; }

    // ─── Circular Health Ring ──────────────────────────────────────────────────
    [Header("Health Ring")]
    [Tooltip("The radial-filled Image representing the health ring.")]
    [SerializeField] private Image           healthRingFill;
    [Tooltip("Numeric health label inside the ring.")]
    [SerializeField] private TextMeshProUGUI healthValueText;
    [Tooltip("Gradient: full health (green) → low health (red).")]
    [SerializeField] private Gradient        healthGradient;

    [Header("Health Smooth")]
    [Tooltip("Speed at which the health ring animates to its target value.")]
    [SerializeField] private float healthSmoothSpeed = 4f;
    private float healthRingTarget;
    private float healthRingCurrent;

    // ─── Score ─────────────────────────────────────────────────────────────────
    [Header("Score")]
    [SerializeField] private TextMeshProUGUI scoreText;

    // ─── Gravity Direction Indicator ───────────────────────────────────────────
    [Header("Gravity Indicator")]
    [Tooltip("Arrow image that rotates to show gravity direction.")]
    [SerializeField] private RectTransform gravityArrow;
    [Tooltip("Label showing current direction (e.g. 'DOWN').")]
    [SerializeField] private TextMeshProUGUI gravityLabel;
    [Tooltip("Background tint of the indicator — shifts color per direction.")]
    [SerializeField] private Image gravityIndicatorBG;

    // Color per gravity direction: Down, Up, Left, Right
    private static readonly Color[] DirColors = new Color[]
    {
        new Color(0.00f, 0.60f, 1.00f), // Down  – blue
        new Color(0.60f, 0.00f, 1.00f), // Up    – purple
        new Color(0.00f, 1.00f, 0.70f), // Left  – teal
        new Color(1.00f, 0.40f, 0.00f), // Right – orange
    };
    private static readonly string[] DirLabels = { "DOWN", "UP", "LEFT", "RIGHT" };
    // Arrow resting angle = 270° (pointing down); rotate by direction delta
    private static readonly float[] DirAngles  = { 270f, 90f, 180f, 0f };

    // ─── Cooldown Bar ──────────────────────────────────────────────────────────
    [Header("Cooldown Bar")]
    [Tooltip("Slider or filled Image for the gravity-shift cooldown.")]
    [SerializeField] private Image cooldownBarFill;
    [Tooltip("'READY' label shown when cooldown is 0.")]
    [SerializeField] private TextMeshProUGUI cooldownLabel;

    // ─── Chaos Mode ────────────────────────────────────────────────────────────
    [Header("Chaos Mode")]
    [SerializeField] private GameObject chaosModeLabel;

    // ─── Heal Popup ────────────────────────────────────────────────────────────
    [Header("Heal Popup")]
    [SerializeField] private GameObject healPopupPrefab;
    [SerializeField] private Canvas     worldCanvas;

    // ─── Game Over ─────────────────────────────────────────────────────────────
    [Header("Game Over")]
    [SerializeField] private GameObject gameOverPanel;

    // ─────────────────────────────────────────────────────────────────────────
    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
    }

    private void Start()
    {
        // Subscribe to events
        if (GSGameManager.Instance != null)
        {
            GSGameManager.Instance.OnHealthChanged += HandleHealthChanged;
            GSGameManager.Instance.OnScoreChanged  += HandleScoreChanged;
            GSGameManager.Instance.OnGameOver      += HandleGameOver;
        }
        if (GravitySystem.Instance != null)
            GravitySystem.Instance.OnGravityShifted += HandleGravityShifted;

        // Init UI
        int hp  = GSGameManager.Instance?.CurrentHealth ?? 100;
        int max = GSGameManager.Instance?.MaxHealth     ?? 100;
        healthRingTarget  = (float)hp / max;
        healthRingCurrent = healthRingTarget;

        if (healthRingFill != null) healthRingFill.fillAmount = healthRingCurrent;
        if (scoreText      != null) scoreText.text = "00000";
        if (gameOverPanel  != null) gameOverPanel.SetActive(false);
        if (chaosModeLabel != null) chaosModeLabel.SetActive(false);

        HandleGravityShifted(GravitySystem.GravityDir.Down);
    }

    private void OnDestroy()
    {
        if (GSGameManager.Instance != null)
        {
            GSGameManager.Instance.OnHealthChanged -= HandleHealthChanged;
            GSGameManager.Instance.OnScoreChanged  -= HandleScoreChanged;
            GSGameManager.Instance.OnGameOver      -= HandleGameOver;
        }
        if (GravitySystem.Instance != null)
            GravitySystem.Instance.OnGravityShifted -= HandleGravityShifted;
    }

    private void Update()
    {
        // Smooth health ring animation
        healthRingCurrent = Mathf.Lerp(healthRingCurrent, healthRingTarget,
                                        Time.deltaTime * healthSmoothSpeed);
        if (healthRingFill != null)
        {
            healthRingFill.fillAmount = healthRingCurrent;
            // Color gradient evaluation
            healthRingFill.color = healthGradient.Evaluate(healthRingCurrent);
        }

        // Update cooldown bar
        UpdateCooldownBar();
    }

    // ─── Health ────────────────────────────────────────────────────────────────

    private void HandleHealthChanged(int current, int max)
    {
        healthRingTarget = max > 0 ? (float)current / max : 0f;
        if (healthValueText != null)
            healthValueText.text = current.ToString();
    }

    // ─── Score ─────────────────────────────────────────────────────────────────

    private void HandleScoreChanged(int score)
    {
        if (scoreText != null)
            scoreText.text = score.ToString("D5");
    }

    // ─── Gravity Indicator ─────────────────────────────────────────────────────

    private void HandleGravityShifted(GravitySystem.GravityDir dir)
    {
        int idx = (int)dir;

        // Rotate arrow sprite
        if (gravityArrow != null)
            StartCoroutine(AnimateArrowRotation(DirAngles[idx]));

        // Update label
        if (gravityLabel != null)
            gravityLabel.text = DirLabels[idx];

        // Update background color
        if (gravityIndicatorBG != null)
            StartCoroutine(AnimateIndicatorColor(DirColors[idx]));
    }

    private System.Collections.IEnumerator AnimateArrowRotation(float targetDeg)
    {
        float elapsed  = 0f;
        float duration = 0.2f;
        float current  = gravityArrow.localEulerAngles.z;
        while (elapsed < duration)
        {
            elapsed += Time.unscaledDeltaTime;
            float t  = Mathf.Clamp01(elapsed / duration);
            float a  = Mathf.LerpAngle(current, targetDeg, t);
            gravityArrow.localEulerAngles = new Vector3(0f, 0f, a);
            yield return null;
        }
        gravityArrow.localEulerAngles = new Vector3(0f, 0f, targetDeg);
    }

    private System.Collections.IEnumerator AnimateIndicatorColor(Color target)
    {
        float elapsed  = 0f;
        float duration = 0.25f;
        Color start    = gravityIndicatorBG.color;
        while (elapsed < duration)
        {
            elapsed  += Time.unscaledDeltaTime;
            gravityIndicatorBG.color = Color.Lerp(start, target, elapsed / duration);
            yield return null;
        }
        gravityIndicatorBG.color = target;
    }

    // ─── Cooldown Bar ──────────────────────────────────────────────────────────

    private void UpdateCooldownBar()
    {
        if (GravitySystem.Instance == null || cooldownBarFill == null) return;

        // Progress: 1 = just shifted (full bar = cooling down), 0 = ready
        float progress = GravitySystem.Instance.CooldownProgress;
        float fill     = 1f - progress; // invert: fills up as it cools down
        cooldownBarFill.fillAmount = fill;

        bool ready = GravitySystem.Instance.IsReady;
        if (cooldownLabel != null)
            cooldownLabel.text = ready ? "SHIFT READY" : "SHIFTING...";

        // Color: green when ready, dim when cooling
        cooldownBarFill.color = ready
            ? new Color(0.00f, 1.00f, 0.70f)
            : new Color(0.50f, 0.25f, 0.80f);
    }

    // ─── Chaos Mode ────────────────────────────────────────────────────────────

    public void SetChaosModeVisible(bool visible)
    {
        if (chaosModeLabel != null) chaosModeLabel.SetActive(visible);
    }

    // ─── Heal Popup ────────────────────────────────────────────────────────────

    public void SpawnHealPopup(int amount, Vector3 worldPos)
    {
        if (healPopupPrefab == null || worldCanvas == null) return;
        var go  = Instantiate(healPopupPrefab, worldPos, Quaternion.identity, worldCanvas.transform);
        var tmp = go.GetComponentInChildren<TextMeshProUGUI>();
        if (tmp != null)
        {
            tmp.text  = $"+{amount} HP";
            tmp.color = new Color(0.3f, 1f, 0.6f);
        }
        Destroy(go, 1.2f);
    }

    // ─── Game Over ─────────────────────────────────────────────────────────────

    private void HandleGameOver()
    {
        if (gameOverPanel != null)
            gameOverPanel.SetActive(true);
    }
}
