using UnityEngine;
using System;

/// <summary>
/// GRAVITY SHIFT: CORE ESCAPE — Gravity System
/// ══════════════════════════════════════════════════════════════
/// The core mechanic: the player can shift gravity in 4 directions
/// using W / A / S / D (or arrow keys).
///
/// Changing gravity direction:
///   W / Up    → Gravity pulls UP    (inverse of normal)
///   S / Down  → Gravity pulls DOWN  (default)
///   A / Left  → Gravity pulls LEFT
///   D / Right → Gravity pulls RIGHT
///
/// This physically sets Physics2D.gravity and fires an event so the
/// Gravity Direction Indicator UI can update immediately.
///
/// Cooldown prevents spamming — the player must wait before shifting again.
/// ══════════════════════════════════════════════════════════════
/// Attach to an empty "GravitySystem" GameObject.
/// </summary>
public class GravitySystem : MonoBehaviour
{
    // ─── Singleton ─────────────────────────────────────────────────────────────
    public static GravitySystem Instance { get; private set; }

    // ─── Gravity Directions ────────────────────────────────────────────────────
    public enum GravityDir { Down, Up, Left, Right }

    private static readonly Vector2[] GravityVectors = new Vector2[]
    {
        new Vector2(  0f, -1f),  // Down
        new Vector2(  0f,  1f),  // Up
        new Vector2( -1f,  0f),  // Left
        new Vector2(  1f,  0f),  // Right
    };

    // ─── Settings ──────────────────────────────────────────────────────────────
    [Header("Gravity Strength")]
    [Tooltip("Magnitude of gravity acceleration (units/s²).")]
    [SerializeField] private float gravityStrength = 18f;

    [Header("Shift Cooldown")]
    [Tooltip("Seconds the player must wait between gravity shifts.")]
    [SerializeField] private float shiftCooldown = 0.35f;

    [Header("Chaos Mode")]
    [Tooltip("Seconds between random gravity flips during Chaos Mode.")]
    [SerializeField] private float chaosFlipInterval = 0.6f;

    // ─── State ─────────────────────────────────────────────────────────────────
    private GravityDir currentDirection = GravityDir.Down;
    private float      cooldownTimer;
    private bool       chaosActive;
    private float      chaosTimer;

    public GravityDir  CurrentDirection  => currentDirection;
    public float       CooldownProgress  => Mathf.Clamp01(cooldownTimer / shiftCooldown); // 0=ready, 1=just shifted
    public bool        IsReady           => cooldownTimer <= 0f;
    public bool        ChaosActive       => chaosActive;

    // ─── Events ────────────────────────────────────────────────────────────────
    public event Action<GravityDir> OnGravityShifted;   // fires when direction changes
    public event Action             OnChaosModeStarted;
    public event Action             OnChaosModeEnded;

    // ─────────────────────────────────────────────────────────────────────────
    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
    }

    private void Start()
    {
        ApplyGravity(GravityDir.Down); // start with normal gravity
    }

    private void Update()
    {
        if (GSGameManager.Instance != null && GSGameManager.Instance.IsGameOver) return;

        // Cooldown countdown
        if (cooldownTimer > 0f) cooldownTimer -= Time.deltaTime;

        // Chaos Mode random flip
        if (chaosActive)
        {
            chaosTimer -= Time.deltaTime;
            if (chaosTimer <= 0f)
            {
                ShiftRandom();
                chaosTimer = chaosFlipInterval;
            }
            return; // player input disabled during chaos
        }

        // Player input
        ReadInput();
    }

    // ─── Input ─────────────────────────────────────────────────────────────────

    private void ReadInput()
    {
        if (!IsReady) return;

        if (Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.UpArrow))
            Shift(GravityDir.Up);
        else if (Input.GetKeyDown(KeyCode.S) || Input.GetKeyDown(KeyCode.DownArrow))
            Shift(GravityDir.Down);
        else if (Input.GetKeyDown(KeyCode.A) || Input.GetKeyDown(KeyCode.LeftArrow))
            Shift(GravityDir.Left);
        else if (Input.GetKeyDown(KeyCode.D) || Input.GetKeyDown(KeyCode.RightArrow))
            Shift(GravityDir.Right);
    }

    // ─── Gravity Shift API ─────────────────────────────────────────────────────

    /// <summary>Shifts gravity to the given direction with cooldown.</summary>
    public void Shift(GravityDir dir)
    {
        if (dir == currentDirection) return; // no-op if already that direction
        ApplyGravity(dir);
        cooldownTimer = shiftCooldown;
    }

    /// <summary>Instantly applies gravity to a direction without cooldown (used by Chaos Mode).</summary>
    public void ShiftRandom()
    {
        GravityDir r;
        do { r = (GravityDir)UnityEngine.Random.Range(0, 4); } while (r == currentDirection);
        ApplyGravity(r);
    }

    private void ApplyGravity(GravityDir dir)
    {
        currentDirection = dir;
        Physics2D.gravity = GravityVectors[(int)dir] * gravityStrength;
        OnGravityShifted?.Invoke(dir);
    }

    // ─── Chaos Mode API ────────────────────────────────────────────────────────

    public void StartChaosMode()
    {
        if (chaosActive) return;
        chaosActive = true;
        chaosTimer  = chaosFlipInterval;
        OnChaosModeStarted?.Invoke();
    }

    public void StopChaosMode()
    {
        if (!chaosActive) return;
        chaosActive = false;
        Shift(GravityDir.Down); // reset to sane default
        OnChaosModeEnded?.Invoke();
    }

    private void OnDestroy()
    {
        // Always restore normal gravity when the scene unloads
        Physics2D.gravity = Vector2.down * 9.81f;
    }
}
