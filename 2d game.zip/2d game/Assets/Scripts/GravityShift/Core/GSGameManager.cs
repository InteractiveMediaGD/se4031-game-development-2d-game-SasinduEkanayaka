using UnityEngine;
using UnityEngine.SceneManagement;
using System;

/// <summary>
/// GRAVITY SHIFT: CORE ESCAPE — Central Game Manager
/// ══════════════════════════════════════════════════════════════
/// Singleton that owns all game-wide state:
///   • Health (max / current, events on change)
///   • Score (time-based + kill bonus)
///   • Difficulty speed ramp
///   • Game Over / Restart / Main Menu flow
///
/// Other systems subscribe to events (OnHealthChanged, OnScoreChanged,
/// OnGameOver) instead of polling — clean architecture, no Update polling.
/// ══════════════════════════════════════════════════════════════
/// Attach to an empty "GSGameManager" GameObject in the GravityShift scene.
/// </summary>
public class GSGameManager : MonoBehaviour
{
    // ─── Singleton ─────────────────────────────────────────────────────────────
    public static GSGameManager Instance { get; private set; }

    // ─── Health ────────────────────────────────────────────────────────────────
    [Header("Health")]
    [SerializeField] private int maxHealth         = 100;
    [SerializeField] private int currentHealth     = 100;

    public int  MaxHealth     => maxHealth;
    public int  CurrentHealth => currentHealth;
    public float HealthPercent => maxHealth > 0 ? (float)currentHealth / maxHealth : 0f;

    // ─── Score ─────────────────────────────────────────────────────────────────
    [Header("Score")]
    [SerializeField] private float scorePerSecond  = 8f;
    [SerializeField] private int   enemyKillBonus  = 75;

    private float scoreAccum;
    private int   currentScore;

    public int CurrentScore => currentScore;

    // ─── Speed Ramp ────────────────────────────────────────────────────────────
    [Header("Difficulty")]
    [SerializeField] private float baseSpeed             = 3.5f;
    [SerializeField] private float speedIncreasePerSec   = 0.02f;
    [SerializeField] private float maxSpeed              = 14f;

    private float currentSpeed;
    public  float CurrentSpeed => currentSpeed;

    // ─── State ─────────────────────────────────────────────────────────────────
    private bool isGameOver;
    public  bool IsGameOver => isGameOver;

    // ─── PlayerPrefs Keys ──────────────────────────────────────────────────────
    private const string KEY_HIGHSCORE = "GS_HighScore";

    public int HighScore { get; private set; }

    // ─── Events ────────────────────────────────────────────────────────────────
    public event Action<int, int> OnHealthChanged;   // (current, max)
    public event Action<int>      OnScoreChanged;    // (score)
    public event Action<float>    OnSpeedChanged;    // (speed)
    public event Action           OnGameOver;

    // ─────────────────────────────────────────────────────────────────────────
    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
    }

    private void Start()
    {
        currentHealth = maxHealth;
        currentSpeed  = baseSpeed;
        HighScore     = PlayerPrefs.GetInt(KEY_HIGHSCORE, 0);
    }

    private void Update()
    {
        if (isGameOver) return;

        // Score accumulation
        scoreAccum += scorePerSecond * Time.deltaTime;
        if (scoreAccum >= 1f)
        {
            int pts = Mathf.FloorToInt(scoreAccum);
            scoreAccum -= pts;
            AddScore(pts);
        }

        // Speed ramp
        float newSpeed = Mathf.Min(currentSpeed + speedIncreasePerSec * Time.deltaTime, maxSpeed);
        if (!Mathf.Approximately(newSpeed, currentSpeed))
        {
            currentSpeed = newSpeed;
            OnSpeedChanged?.Invoke(currentSpeed);
        }
    }

    // ─── Health API ────────────────────────────────────────────────────────────

    public void TakeDamage(int amount)
    {
        if (isGameOver) return;
        currentHealth = Mathf.Max(0, currentHealth - Mathf.Abs(amount));
        OnHealthChanged?.Invoke(currentHealth, maxHealth);
        if (currentHealth <= 0) TriggerGameOver();
    }

    public void Heal(int amount)
    {
        if (isGameOver) return;
        currentHealth = Mathf.Min(maxHealth, currentHealth + Mathf.Abs(amount));
        OnHealthChanged?.Invoke(currentHealth, maxHealth);
    }

    // ─── Score API ─────────────────────────────────────────────────────────────

    public void AddScore(int amount)
    {
        if (isGameOver) return;
        currentScore += amount;
        OnScoreChanged?.Invoke(currentScore);
    }

    public void AddKillScore() => AddScore(enemyKillBonus);

    // ─── Game State ────────────────────────────────────────────────────────────

    private void TriggerGameOver()
    {
        if (isGameOver) return;
        isGameOver = true;

        // Save high score
        if (currentScore > HighScore)
        {
            HighScore = currentScore;
            PlayerPrefs.SetInt(KEY_HIGHSCORE, HighScore);
            PlayerPrefs.Save();
        }

        // Slow-motion death moment then fully pause
        Time.timeScale = 0.3f;
        Invoke(nameof(FinalPause), 0.4f * 0.3f); // real-time delay

        OnGameOver?.Invoke();
    }

    private void FinalPause() => Time.timeScale = 0f;

    public void RestartGame()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    public void GoToMainMenu()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene("GS_MainMenu");
    }
}
