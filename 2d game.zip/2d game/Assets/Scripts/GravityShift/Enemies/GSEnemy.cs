using System.Collections;
using UnityEngine;

/// <summary>
/// GRAVITY SHIFT: CORE ESCAPE — Enemy
/// ══════════════════════════════════════════════════════════════
/// Enemy that chases the player, adapting to the current gravity
/// direction so it always approaches from a threatening angle.
///
/// Behavior modes:
///   CHASER  – accelerates toward player continuously
///   BOUNCER – bounces off walls, changes direction on impact
///
/// The enemy is NOT affected by Physics2D gravity (gravity scale = 0)
/// so it can fly freely inside the core regardless of gravity shifts.
/// ══════════════════════════════════════════════════════════════
/// Tags required: "GSEnemy" on this object.
/// Prefab: Rigidbody2D (gravityScale=0), CircleCollider2D (isTrigger).
/// </summary>
[RequireComponent(typeof(Rigidbody2D))]
public class GSEnemy : MonoBehaviour
{
    public enum EnemyMode { Chaser, Bouncer }

    [Header("Behavior")]
    [SerializeField] private EnemyMode mode = EnemyMode.Chaser;

    [Header("Chase Settings")]
    [Tooltip("Max speed the enemy chases the player.")]
    [SerializeField] private float chaseSpeed      = 3.5f;
    [Tooltip("Acceleration toward the player per second.")]
    [SerializeField] private float acceleration    = 6f;

    [Header("Bouncer Settings")]
    [SerializeField] private float bouncerSpeed    = 4f;
    [SerializeField] private float bounceRandAngle = 25f;

    [Header("Score")]
    [SerializeField] private int killScore = 75;

    [Header("Effects")]
    [SerializeField] private GameObject deathFXPrefab;

    [Header("Visuals")]
    [Tooltip("Sprite rotates to face movement direction.")]
    [SerializeField] private bool rotateFacingDir = true;

    // ─── Runtime ───────────────────────────────────────────────────────────────
    private Rigidbody2D rb;
    private Transform   playerTransform;
    private bool        isDead;
    private Vector2     bouncerVelocity;

    // ─────────────────────────────────────────────────────────────────────────
    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        rb.gravityScale = 0f; // floats freely inside the core
        rb.drag         = 0.5f;
    }

    private void Start()
    {
        GameObject playerGO = GameObject.FindGameObjectWithTag("GSPlayer");
        if (playerGO != null) playerTransform = playerGO.transform;

        if (mode == EnemyMode.Bouncer)
        {
            // Start with a random velocity
            float angle = Random.Range(0f, 360f) * Mathf.Deg2Rad;
            bouncerVelocity = new Vector2(Mathf.Cos(angle), Mathf.Sin(angle)) * bouncerSpeed;
        }
    }

    private void FixedUpdate()
    {
        if (isDead) return;
        if (GSGameManager.Instance != null && GSGameManager.Instance.IsGameOver) return;

        switch (mode)
        {
            case EnemyMode.Chaser:  UpdateChaser();  break;
            case EnemyMode.Bouncer: UpdateBouncer(); break;
        }

        if (rotateFacingDir && rb.velocity.sqrMagnitude > 0.01f)
        {
            float angle = Mathf.Atan2(rb.velocity.y, rb.velocity.x) * Mathf.Rad2Deg - 90f;
            transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);
        }
    }

    // ─── Chaser ────────────────────────────────────────────────────────────────

    private void UpdateChaser()
    {
        if (playerTransform == null) return;

        Vector2 toPlayer  = (playerTransform.position - transform.position).normalized;
        float   speedMult = GSGameManager.Instance != null
            ? GSGameManager.Instance.CurrentSpeed / 3.5f
            : 1f;

        Vector2 desired = toPlayer * chaseSpeed * speedMult;
        rb.velocity = Vector2.MoveTowards(rb.velocity, desired, acceleration * Time.fixedDeltaTime);
    }

    // ─── Bouncer ───────────────────────────────────────────────────────────────

    private void UpdateBouncer()
    {
        rb.velocity = bouncerVelocity;
    }

    private void OnCollisionEnter2D(Collision2D col)
    {
        if (mode != EnemyMode.Bouncer) return;
        // Reflect off any wall
        Vector2 normal     = col.contacts[0].normal;
        float   extraAngle = Random.Range(-bounceRandAngle, bounceRandAngle) * Mathf.Deg2Rad;
        bouncerVelocity    = Vector2.Reflect(bouncerVelocity, normal).normalized * bouncerSpeed;
    }

    // ─── Trigger ───────────────────────────────────────────────────────────────
    // Player contact is handled in GSPlayerController

    // ─── Death ─────────────────────────────────────────────────────────────────

    public void DestroyEnemy(bool awardScore)
    {
        if (isDead) return;
        isDead = true;

        if (awardScore) GSGameManager.Instance?.AddScore(killScore);

        if (deathFXPrefab != null)
            Instantiate(deathFXPrefab, transform.position, Quaternion.identity);

        GSFXManager.Instance?.PlayEnemyDeathEffect(transform.position);

        Destroy(gameObject);
    }
}
