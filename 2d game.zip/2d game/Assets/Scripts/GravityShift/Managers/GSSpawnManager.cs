using UnityEngine;

/// <summary>
/// GRAVITY SHIFT: CORE ESCAPE — Spawn Manager
/// ══════════════════════════════════════════════════════════════
/// Spawns enemies and health packs inside the core arena.
/// Spawn positions adapt to the current gravity direction —
/// enemies always appear on the opposite wall from where the
/// player is being pulled (maximizing challenge).
///
/// Uses distance/time-based spawning that accelerates with
/// the game's difficulty speed multiplier.
/// ══════════════════════════════════════════════════════════════
/// Attach to an empty "GSSpawnManager" GameObject.
/// </summary>
public class GSSpawnManager : MonoBehaviour
{
    [Header("Prefabs")]
    [SerializeField] private GameObject chaserPrefab;
    [SerializeField] private GameObject bouncerPrefab;
    [SerializeField] private GameObject healthPackPrefab;

    [Header("Spawn Bounds (match camera)")]
    [SerializeField] private float arenaW = 7.5f;   // half-width
    [SerializeField] private float arenaH = 4.5f;   // half-height
    [SerializeField] private float spawnEdgeOffset = 0.8f; // spawn slightly off edge

    [Header("Enemy Timing")]
    [Tooltip("Base interval between enemy spawns (seconds).")]
    [SerializeField] private float baseEnemyInterval   = 3.5f;
    [Tooltip("Minimum interval (clamped as speed increases).")]
    [SerializeField] private float minEnemyInterval    = 0.8f;
    [Tooltip("How fast the interval shrinks per unit of game speed.")]
    [SerializeField] private float intervalDecayRate   = 0.1f;

    [Header("Bouncer Ratio")]
    [Tooltip("0 = all chasers, 1 = all bouncers.")]
    [Range(0f, 1f)]
    [SerializeField] private float bouncerChance       = 0.30f;

    [Header("Health Pack Timing")]
    [SerializeField] private float healthPackInterval  = 12f;

    [Header("Chaos Mode")]
    [Tooltip("Enemy spawn rate multiplier during Chaos Mode.")]
    [SerializeField] private float chaosSpawnMultiplier = 1.6f;

    // ─── Runtime ───────────────────────────────────────────────────────────────
    private float enemyTimer;
    private float healthTimer;

    private void Start()
    {
        enemyTimer  = baseEnemyInterval * 1.5f; // grace period at start
        healthTimer = healthPackInterval;
    }

    private void Update()
    {
        if (GSGameManager.Instance == null || GSGameManager.Instance.IsGameOver) return;

        float spd = GSGameManager.Instance.CurrentSpeed;
        bool  chaos = GravityChaosModeController.Instance != null &&
                      GravityChaosModeController.Instance.IsChaosActive;

        // Calculate current enemy interval
        float interval = Mathf.Max(minEnemyInterval,
                                   baseEnemyInterval - spd * intervalDecayRate);
        if (chaos) interval /= chaosSpawnMultiplier;

        enemyTimer  -= Time.deltaTime;
        healthTimer -= Time.deltaTime;

        if (enemyTimer <= 0f)
        {
            SpawnEnemy();
            enemyTimer = interval;
        }

        if (healthTimer <= 0f)
        {
            SpawnHealthPack();
            healthTimer = healthPackInterval;
        }
    }

    // ─── Spawn Helpers ─────────────────────────────────────────────────────────

    private void SpawnEnemy()
    {
        // Choose prefab
        GameObject prefab = (Random.value < bouncerChance && bouncerPrefab != null)
            ? bouncerPrefab : chaserPrefab;
        if (prefab == null) return;

        // Spawn on the wall OPPOSITE to current gravity pull
        Vector3 pos = GetSpawnPosition();
        Instantiate(prefab, pos, Quaternion.identity);
    }

    private void SpawnHealthPack()
    {
        if (healthPackPrefab == null) return;
        // Health packs spawn near center to be collectible from multiple gravity states
        float x = Random.Range(-arenaW * 0.5f, arenaW * 0.5f);
        float y = Random.Range(-arenaH * 0.5f, arenaH * 0.5f);
        Instantiate(healthPackPrefab, new Vector3(x, y, 0f), Quaternion.identity);
    }

    /// <summary>
    /// Returns a random spawn position on the wall opposite to current gravity.
    /// The enemy spawns on that wall and chases the player who is being pushed
    /// to the opposite wall.
    /// </summary>
    private Vector3 GetSpawnPosition()
    {
        GravitySystem.GravityDir dir = GravitySystem.Instance != null
            ? GravitySystem.Instance.CurrentDirection
            : GravitySystem.GravityDir.Down;

        float rand;
        switch (dir)
        {
            case GravitySystem.GravityDir.Down:
                // Player falls to bottom wall → enemies spawn at top
                rand = Random.Range(-arenaW, arenaW);
                return new Vector3(rand, arenaH + spawnEdgeOffset, 0f);

            case GravitySystem.GravityDir.Up:
                // Player falls to top wall → enemies spawn at bottom
                rand = Random.Range(-arenaW, arenaW);
                return new Vector3(rand, -arenaH - spawnEdgeOffset, 0f);

            case GravitySystem.GravityDir.Left:
                // Player falls to left wall → enemies spawn on right
                rand = Random.Range(-arenaH, arenaH);
                return new Vector3(arenaW + spawnEdgeOffset, rand, 0f);

            case GravitySystem.GravityDir.Right:
                // Player falls to right wall → enemies spawn on left
                rand = Random.Range(-arenaH, arenaH);
                return new Vector3(-arenaW - spawnEdgeOffset, rand, 0f);

            default:
                return Vector3.zero;
        }
    }
}
