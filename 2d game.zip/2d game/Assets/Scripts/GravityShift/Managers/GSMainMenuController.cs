using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;

/// <summary>
/// GRAVITY SHIFT: CORE ESCAPE — Main Menu Controller
/// ══════════════════════════════════════════════════════════════
/// Drives the main menu scene:
///   1. Fade in from black
///   2. Title "GRAVITY SHIFT" floats in with spring animation + glow
///   3. Subtitle "CORE ESCAPE" fades in below
///   4. Buttons appear with staggered delay
///   5. Galaxy background stars drift behind everything
///   6. Settings panel slides in/out
///   7. Smooth fade-to-black transition when starting
/// ══════════════════════════════════════════════════════════════
/// Attach to "GSMainMenuController" in the GS_MainMenu scene.
/// </summary>
public class GSMainMenuController : MonoBehaviour
{
    // ─── Scene ─────────────────────────────────────────────────────────────────
    [Header("Scene")]
    [SerializeField] private string gameSceneName = "GS_GameScene";

    // ─── Title ─────────────────────────────────────────────────────────────────
    [Header("Title")]
    [SerializeField] private RectTransform    titleTransform;
    [SerializeField] private CanvasGroup      titleGroup;
    [SerializeField] private TextMeshProUGUI  subtitleText;
    [SerializeField] private CanvasGroup      subtitleGroup;
    [SerializeField] private TextMeshProUGUI  highScoreLabel;

    // ─── Buttons ───────────────────────────────────────────────────────────────
    [Header("Buttons")]
    [SerializeField] private CanvasGroup   mainButtonsGroup;
    [SerializeField] private Button        startButton;
    [SerializeField] private Button        settingsButton;
    [SerializeField] private Button        exitButton;

    // ─── Settings Panel ────────────────────────────────────────────────────────
    [Header("Settings Panel")]
    [SerializeField] private RectTransform settingsPanel;
    [SerializeField] private Button        settingsCloseButton;
    [SerializeField] private Slider        sfxVolumeSlider;
    [SerializeField] private Slider        musicVolumeSlider;

    // ─── Screen Fade ───────────────────────────────────────────────────────────
    [Header("Fade")]
    [SerializeField] private Image fadeOverlay;

    // ─── Animation Timings ─────────────────────────────────────────────────────
    [Header("Timings")]
    [SerializeField] private float fadeInDuration      = 0.5f;
    [SerializeField] private float titleDuration       = 1.0f;
    [SerializeField] private float titleStartOffset    = -120f;
    [SerializeField] private float subtitleDelay       = 0.35f;
    [SerializeField] private float subtitleDuration    = 0.6f;
    [SerializeField] private float buttonDelay         = 0.5f;
    [SerializeField] private float buttonFadeDuration  = 0.5f;
    [SerializeField] private float titlePulseSpeed     = 1.2f;

    // ─── Runtime ───────────────────────────────────────────────────────────────
    private bool   isTransitioning;
    private bool   settingsOpen;
    private float  pulseTimer;
    private Vector2 settingsPanelHidePos;

    // ─────────────────────────────────────────────────────────────────────────
    private void Start()
    {
        // Lock buttons until intro finishes
        SetButtonsInteractable(false);
        SetFade(1f);

        // High score
        int hs = PlayerPrefs.GetInt("GS_HighScore", 0);
        if (highScoreLabel != null) highScoreLabel.text = $"BEST  {hs:D6}";

        // Hide settings panel off-screen initially
        if (settingsPanel != null)
        {
            settingsPanelHidePos = new Vector2(settingsPanel.anchoredPosition.x + 600f,
                                               settingsPanel.anchoredPosition.y);
            settingsPanel.anchoredPosition = settingsPanelHidePos;
        }

        StartCoroutine(IntroSequence());
    }

    private void Update()
    {
        if (!isTransitioning && titleGroup != null)
        {
            pulseTimer += Time.deltaTime * titlePulseSpeed;
            float t = (Mathf.Sin(pulseTimer) + 1f) * 0.5f;
            titleGroup.alpha = Mathf.Lerp(0.75f, 1f, t);
        }
    }

    // ─── Intro Sequence ────────────────────────────────────────────────────────

    private IEnumerator IntroSequence()
    {
        // Reset all to start state
        if (titleGroup   != null) titleGroup.alpha   = 0f;
        if (subtitleGroup != null) subtitleGroup.alpha = 0f;
        if (mainButtonsGroup != null) mainButtonsGroup.alpha = 0f;

        Vector2 titleRest = titleTransform != null ? titleTransform.anchoredPosition : Vector2.zero;
        if (titleTransform != null)
            titleTransform.anchoredPosition = titleRest + Vector2.up * (-titleStartOffset);

        // Phase 0: fade in from black
        yield return StartCoroutine(FadeOverlay(1f, 0f, fadeInDuration));

        yield return new WaitForSeconds(0.1f);

        // Phase 1: title springs in
        float elapsed = 0f;
        while (elapsed < titleDuration)
        {
            elapsed += Time.deltaTime;
            float t  = Mathf.Clamp01(elapsed / titleDuration);
            float te = EaseOutBack(t);
            if (titleGroup     != null) titleGroup.alpha = te;
            if (titleTransform != null)
                titleTransform.anchoredPosition = Vector2.Lerp(
                    titleRest + Vector2.up * (-titleStartOffset), titleRest, te);
            yield return null;
        }
        if (titleGroup     != null) titleGroup.alpha = 1f;
        if (titleTransform != null) titleTransform.anchoredPosition = titleRest;

        yield return new WaitForSeconds(subtitleDelay);

        // Phase 2: subtitle fades in
        elapsed = 0f;
        while (elapsed < subtitleDuration)
        {
            elapsed += Time.deltaTime;
            if (subtitleGroup != null) subtitleGroup.alpha = elapsed / subtitleDuration;
            yield return null;
        }
        if (subtitleGroup != null) subtitleGroup.alpha = 1f;

        yield return new WaitForSeconds(buttonDelay);

        // Phase 3: buttons fade in
        elapsed = 0f;
        while (elapsed < buttonFadeDuration)
        {
            elapsed += Time.deltaTime;
            if (mainButtonsGroup != null) mainButtonsGroup.alpha = elapsed / buttonFadeDuration;
            yield return null;
        }
        if (mainButtonsGroup != null) mainButtonsGroup.alpha = 1f;

        SetButtonsInteractable(true);
    }

    // ─── Button Callbacks ──────────────────────────────────────────────────────

    public void OnStartClicked()
    {
        if (isTransitioning) return;
        StartCoroutine(StartTransition());
    }

    public void OnSettingsClicked()
    {
        if (isTransitioning) return;
        if (settingsOpen) CloseSettings();
        else              OpenSettings();
    }

    public void OnSettingsCloseClicked() => CloseSettings();

    public void OnExitClicked()
    {
        if (isTransitioning) return;
        StartCoroutine(ExitTransition());
    }

    // ─── Settings Panel ────────────────────────────────────────────────────────

    private void OpenSettings()
    {
        settingsOpen = true;
        if (settingsPanel != null) StopCoroutine("AnimateSettings");
        StartCoroutine(AnimateSettings(settingsPanelHidePos,
                                       settingsPanelHidePos - new Vector2(600f, 0f), 0.35f));
    }

    private void CloseSettings()
    {
        settingsOpen = false;
        if (settingsPanel != null) StopCoroutine("AnimateSettings");
        Vector2 restPos = settingsPanelHidePos - new Vector2(600f, 0f);
        StartCoroutine(AnimateSettings(restPos, settingsPanelHidePos, 0.35f));
    }

    private IEnumerator AnimateSettings(Vector2 from, Vector2 to, float dur)
    {
        if (settingsPanel == null) yield break;
        float elapsed = 0f;
        while (elapsed < dur)
        {
            elapsed += Time.deltaTime;
            float t  = Mathf.SmoothStep(0f, 1f, Mathf.Clamp01(elapsed / dur));
            settingsPanel.anchoredPosition = Vector2.Lerp(from, to, t);
            yield return null;
        }
        settingsPanel.anchoredPosition = to;
    }

    // ─── Transitions ───────────────────────────────────────────────────────────

    private IEnumerator StartTransition()
    {
        isTransitioning = true;
        SetButtonsInteractable(false);
        yield return StartCoroutine(FadeOverlay(0f, 1f, 0.5f));
        Time.timeScale = 1f;
        SceneManager.LoadScene(gameSceneName);
    }

    private IEnumerator ExitTransition()
    {
        isTransitioning = true;
        SetButtonsInteractable(false);
        yield return StartCoroutine(FadeOverlay(0f, 1f, 0.5f));
        Application.Quit();
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#endif
    }

    // ─── Helpers ───────────────────────────────────────────────────────────────

    private IEnumerator FadeOverlay(float from, float to, float dur)
    {
        float elapsed = 0f;
        while (elapsed < dur)
        {
            elapsed += Time.deltaTime;
            SetFade(Mathf.Lerp(from, to, elapsed / dur));
            yield return null;
        }
        SetFade(to);
    }

    private void SetFade(float alpha)
    {
        if (fadeOverlay != null) fadeOverlay.color = new Color(0f, 0f, 0f, alpha);
    }

    private void SetButtonsInteractable(bool v)
    {
        if (startButton    != null) startButton.interactable    = v;
        if (settingsButton != null) settingsButton.interactable = v;
        if (exitButton     != null) exitButton.interactable     = v;
        if (mainButtonsGroup != null)
        {
            mainButtonsGroup.interactable  = v;
            mainButtonsGroup.blocksRaycasts = v;
        }
    }

    private static float EaseOutBack(float t)
    {
        const float c1 = 1.70158f;
        const float c3 = c1 + 1f;
        float tm1 = t - 1f;
        return 1f + c3 * tm1 * tm1 * tm1 + c1 * tm1 * tm1;
    }
}
