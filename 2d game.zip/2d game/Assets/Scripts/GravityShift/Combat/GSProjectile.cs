using UnityEngine;

/// <summary>
/// GRAVITY SHIFT: CORE ESCAPE — Projectile
/// ══════════════════════════════════════════════════════════════
/// Flies in a straight line at a fixed speed toward the target
/// direction set by GSShooter. Ignores gravity (gravity scale = 0).
///
/// Destroys enemies (GSEnemy tag) and solid obstacles (GSObstacle tag).
/// Auto-destroys after its lifetime elapses.
/// ══════════════════════════════════════════════════════════════
/// Prefab: Rigidbody2D (gravityScale=0, kinematic off),
///         CircleCollider2D (isTrigger), this script.
/// </summary>
[RequireComponent(typeof(Rigidbody2D))]
public class GSProjectile : MonoBehaviour
{
    [SerializeField] private float speed    = 18f;
    [SerializeField] private float lifetime = 2.5f;

    private Rigidbody2D rb;
    private Vector2     direction = Vector2.up;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        rb.gravityScale = 0f; // projectile ignores scene gravity
    }

    private void Start()
    {
        rb.velocity = direction * speed;
        Destroy(gameObject, lifetime);
    }

    public void SetDirection(Vector2 dir)
    {
        if (dir.sqrMagnitude > 0f) direction = dir.normalized;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("GSEnemy"))
        {
            GSEnemy e = other.GetComponent<GSEnemy>();
            e?.DestroyEnemy(awardScore: true);
            SpawnHitEffect();
            Destroy(gameObject);
        }
        else if (other.CompareTag("GSObstacle") || other.CompareTag("GSWall"))
        {
            SpawnHitEffect();
            Destroy(gameObject);
        }
    }

    private void SpawnHitEffect()
    {
        GSFXManager.Instance?.PlayHitEffect(transform.position);
    }
}
