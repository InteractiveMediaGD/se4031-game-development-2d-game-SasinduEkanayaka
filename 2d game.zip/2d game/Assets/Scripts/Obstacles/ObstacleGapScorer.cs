using UnityEngine;

/// <summary>
/// Invisible trigger placed inside the obstacle gap opening.
/// Awards score ONCE when the player successfully passes through the gap.
/// Disables itself after scoring to prevent double-awards.
///
/// ASSIGNMENT COMPLIANCE:
///  ✓ Score only increases when player successfully passes through a hole/gap
///  ✓ One score event per obstacle regardless of how long player overlaps
///
/// This GameObject must be a child of ObstacleSegment.
/// Requires: BoxCollider2D (isTrigger = true)
/// The player must be tagged "Player".
/// </summary>
[RequireComponent(typeof(BoxCollider2D))]
public class ObstacleGapScorer : MonoBehaviour
{
    private BoxCollider2D col;
    private bool hasScored;

    private void Awake()
    {
        col = GetComponent<BoxCollider2D>();
    }

    /// <summary>Resize the trigger collider to exactly match the gap opening.</summary>
    public void Initialize(float gapHeight)
    {
        if (col != null)
        {
            // Thin on X so it only scores once as the obstacle sweeps past the player
            col.size = new Vector2(0.4f, gapHeight);
        }
    }

    /// <summary>Called by ObstacleSegment.Initialize – resets the scorer for each new spawn.</summary>
    public void ResetScorer()
    {
        hasScored = false;
        if (col != null) col.enabled = true;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (hasScored) return;
        if (!other.CompareTag("Player")) return;

        hasScored     = true;
        col.enabled   = false; // stop re-triggering while player is still inside

        GameManager.Instance?.AddGapScore();
        // Spawn "+100" popup above the gap position
        UIManager.Instance?.SpawnScorePopup(100, transform.position + Vector3.up * 0.5f);
    }
}
