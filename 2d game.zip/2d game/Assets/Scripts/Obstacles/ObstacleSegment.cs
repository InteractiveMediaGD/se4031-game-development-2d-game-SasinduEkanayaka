using UnityEngine;

/// <summary>
/// Ancient Ruin Arch obstacle – two wall segments separated by a navigable gap.
/// Spawned and initialized by SpawnManager. Scrolls left via WorldScroller component.
///
/// Prefab hierarchy:
///   ObstacleSegment  [WorldScroller, AutoDestroyOffscreen, THIS script]
///   ├── TopWall      [SpriteRenderer, BoxCollider2D (isTrigger=true), Tag="Obstacle"]
///   ├── BottomWall   [SpriteRenderer, BoxCollider2D (isTrigger=true), Tag="Obstacle"]
///   └── GapScorer    [BoxCollider2D (isTrigger=true), ObstacleGapScorer script]
///
/// ASSIGNMENT COMPLIANCE:
///  ✓ Player collides with walls and takes damage (trigger detection in PlayerHealth)
///  ✓ Player passes THROUGH walls (triggers, not solid colliders – no physics block)
///  ✓ Score only if player passes THROUGH the gap (ObstacleGapScorer)
///
/// Wall positioning is calculated relative to the parent (which sits at y=0).
/// </summary>
public class ObstacleSegment : MonoBehaviour
{
    [Header("Child References – assign in Prefab")]
    [SerializeField] private Transform topWall;
    [SerializeField] private Transform bottomWall;
    [SerializeField] private ObstacleGapScorer gapScorer;

    [Header("Camera Bounds (match Orthographic Size)")]
    [Tooltip("Top edge of the camera view in world units.")]
    [SerializeField] private float screenTop    =  5.5f;
    [Tooltip("Bottom edge of the camera view in world units.")]
    [SerializeField] private float screenBottom = -5.5f;
    [Tooltip("Visual width of the wall segment sprite.")]
    [SerializeField] private float wallWidth = 1f;

    /// <summary>
    /// Sets gap position and sizes walls to fill the screen above and below the gap.
    /// Called by SpawnManager immediately after Instantiate().
    /// </summary>
    public void Initialize(float gapCenterY, float gapHeight)
    {
        float halfGap  = gapHeight * 0.5f;
        float gapTop    = gapCenterY + halfGap;
        float gapBottom = gapCenterY - halfGap;

        // ── Top Wall: from gapTop → screenTop ─────────────────────────────────
        if (topWall != null)
        {
            float height  = Mathf.Max(0.1f, screenTop - gapTop);
            float centerY = gapTop + height * 0.5f;
            topWall.localPosition = new Vector3(0f, centerY, 0f);
            topWall.localScale    = new Vector3(wallWidth, height, 1f);
        }

        // ── Bottom Wall: from screenBottom → gapBottom ────────────────────────
        if (bottomWall != null)
        {
            float height  = Mathf.Max(0.1f, gapBottom - screenBottom);
            float centerY = screenBottom + height * 0.5f;
            bottomWall.localPosition = new Vector3(0f, centerY, 0f);
            bottomWall.localScale    = new Vector3(wallWidth, height, 1f);
        }

        // ── Gap Scorer: sits in the gap opening ───────────────────────────────
        if (gapScorer != null)
        {
            gapScorer.transform.localPosition = new Vector3(0f, gapCenterY, 0f);
            gapScorer.Initialize(gapHeight);
            gapScorer.ResetScorer();
        }
    }
}
