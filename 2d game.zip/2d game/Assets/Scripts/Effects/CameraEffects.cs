using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Screen shake and damage vignette flash.
/// The camera is STATIONARY – shake is applied as a transient position offset
/// that decays smoothly every frame. Uses unscaledDeltaTime so effects still
/// play correctly during the slow-motion death sequence.
///
/// CREATIVE FEATURE SUPPORT:
///   • ShakeOnShoot()        – subtle micro-kick on firing
///   • ShakeOnDamage()       – strong punch on taking damage
///   • FlashDamageVignette() – full-screen red flash on hit
///
/// Singleton for easy access from any script.
/// Attach to an empty "CameraEffects" GameObject.
/// </summary>
public class CameraEffects : MonoBehaviour
{
    public static CameraEffects Instance { get; private set; }

    [Header("Screen Shake")]
    [Tooltip("Shake intensity when the player fires a shot.")]
    [SerializeField] private float shootShakeIntensity  = 0.04f;
    [Tooltip("Shake intensity when the player takes damage.")]
    [SerializeField] private float damageShakeIntensity = 0.28f;
    [Tooltip("How quickly the shake decays (higher = snappier).")]
    [SerializeField] private float shakeDecayRate       = 9f;

    [Header("Damage Vignette")]
    [Tooltip("Full-screen Image (red, stretches to fill). Set alpha via script.")]
    [SerializeField] private Image vignetteImage;
    [Tooltip("Speed at which the vignette fades to transparent.")]
    [SerializeField] private float vignetteFadeSpeed = 4.5f;

    private Transform camTransform;
    private Vector3   camRestPosition;
    private float     currentShakeAmount;

    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;

        Camera cam = Camera.main;
        if (cam != null)
        {
            camTransform   = cam.transform;
            camRestPosition = cam.transform.localPosition;
        }
    }

    private void Start()
    {
        if (vignetteImage != null)
            vignetteImage.color = new Color(1f, 0f, 0f, 0f); // fully transparent initially
    }

    private void Update()
    {
        UpdateShake();
        UpdateVignette();
    }

    // ─── Screen Shake ─────────────────────────────────────────────────────────

    private void UpdateShake()
    {
        if (currentShakeAmount <= 0f || camTransform == null) return;

        // Apply random offset around the rest position
        camTransform.localPosition = camRestPosition +
                                     (Vector3)(Random.insideUnitCircle * currentShakeAmount);

        // Decay using unscaled time so it works during slow-mo / pause
        currentShakeAmount -= shakeDecayRate * Time.unscaledDeltaTime;

        if (currentShakeAmount <= 0f)
        {
            currentShakeAmount = 0f;
            camTransform.localPosition = camRestPosition; // snap back
        }
    }

    public void ShakeOnShoot()
    {
        // Take the maximum of existing + new intensity (don't stack additively)
        currentShakeAmount = Mathf.Max(currentShakeAmount, shootShakeIntensity);
    }

    public void ShakeOnDamage()
    {
        currentShakeAmount = Mathf.Max(currentShakeAmount, damageShakeIntensity);
    }

    // ─── Damage Vignette ──────────────────────────────────────────────────────

    private void UpdateVignette()
    {
        if (vignetteImage == null) return;
        Color c = vignetteImage.color;
        if (c.a > 0f)
        {
            c.a = Mathf.Max(0f, c.a - vignetteFadeSpeed * Time.unscaledDeltaTime);
            vignetteImage.color = c;
        }
    }

    /// <summary>Flash red fullscreen vignette on damage hit.</summary>
    public void FlashDamageVignette()
    {
        if (vignetteImage != null)
            vignetteImage.color = new Color(1f, 0f, 0f, 0.42f);
    }
}
