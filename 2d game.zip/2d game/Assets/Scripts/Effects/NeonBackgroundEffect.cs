using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// NEON VOID SURVIVOR – Main Menu Neon Background Effect
/// ══════════════════════════════════════════════════════════════
/// Spawns floating neon particles in the background of the
/// main menu for an animated, premium feel.
///
/// Each particle is a small quad/sprite that:
///   • Drifts upward at a slow random speed
///   • Fades in and out at the top/bottom of the screen
///   • Has a random neon color (cyan, purple, pink, blue)
///   • Wraps around when it exits the top of the screen
///
/// Purely visual – no physics, no heavy computation.
/// ══════════════════════════════════════════════════════════════
/// Attach to an empty "NeonBackground" GameObject in the MainMenu scene.
/// Assign a Quad prefab or a simple white Sprite prefab.
/// </summary>
public class NeonBackgroundEffect : MonoBehaviour
{
    [Header("Particle Prefab")]
    [Tooltip("A simple quad or sprite prefab (white color – tinted at runtime).")]
    [SerializeField] private GameObject particlePrefab;

    [Header("Spawn Settings")]
    [Tooltip("Number of floating particles in the scene.")]
    [SerializeField] private int particleCount = 40;
    [Tooltip("Horizontal spawn range (screen half-width in world units).")]
    [SerializeField] private float spawnRangeX = 12f;
    [Tooltip("Vertical spawn range.")]
    [SerializeField] private float spawnRangeY = 7f;

    [Header("Movement")]
    [SerializeField] private float minDriftSpeed = 0.3f;
    [SerializeField] private float maxDriftSpeed = 1.2f;
    [Tooltip("Gentle horizontal drift range.")]
    [SerializeField] private float maxHorizontalDrift = 0.15f;

    [Header("Size")]
    [SerializeField] private float minScale = 0.03f;
    [SerializeField] private float maxScale = 0.18f;

    [Header("Neon Colors")]
    [SerializeField] private Color[] neonColors = new Color[]
    {
        new Color(0.00f, 1.00f, 1.00f, 1f), // Cyan
        new Color(0.70f, 0.00f, 1.00f, 1f), // Purple
        new Color(1.00f, 0.00f, 0.70f, 1f), // Hot Pink
        new Color(0.00f, 0.50f, 1.00f, 1f), // Neon Blue
        new Color(0.00f, 1.00f, 0.40f, 1f), // Neon Green
    };

    // ─── Particle Data ─────────────────────────────────────────────────────────
    private struct Particle
    {
        public Transform   transform;
        public SpriteRenderer sr;
        public float       speed;
        public float       driftX;
        public float       phaseOffset;
        public Color       color;
    }

    private List<Particle> particles = new List<Particle>();

    // ─────────────────────────────────────────────────────────────────────────
    private void Start()
    {
        if (particlePrefab == null)
        {
            Debug.LogWarning("[NeonBackgroundEffect] particlePrefab is not assigned. Effect disabled.");
            enabled = false;
            return;
        }

        for (int i = 0; i < particleCount; i++)
            SpawnParticle(randomY: true);
    }

    private void Update()
    {
        float dt = Time.deltaTime;

        for (int i = 0; i < particles.Count; i++)
        {
            Particle p = particles[i];
            if (p.transform == null) continue;

            Vector3 pos = p.transform.position;

            // Drift upward + gentle horizontal sway
            float sway = Mathf.Sin(Time.time * 0.8f + p.phaseOffset) * p.driftX;
            pos.y += p.speed * dt;
            pos.x += sway * dt;

            p.transform.position = pos;

            // Fade based on vertical position (fade in near bottom, out near top)
            float normalizedY = Mathf.InverseLerp(-spawnRangeY, spawnRangeY, pos.y);
            float alpha = normalizedY < 0.1f
                ? Mathf.InverseLerp(0f, 0.1f, normalizedY)
                : normalizedY > 0.9f
                    ? Mathf.InverseLerp(1f, 0.9f, normalizedY)
                    : 1f;

            Color c = p.color;
            c.a = alpha * 0.75f;
            if (p.sr != null) p.sr.color = c;

            // Wrap around when off screen top
            if (pos.y > spawnRangeY)
            {
                pos.y = -spawnRangeY;
                pos.x = Random.Range(-spawnRangeX, spawnRangeX);
                p.transform.position = pos;
            }

            particles[i] = p;
        }
    }

    // ─── Helpers ───────────────────────────────────────────────────────────────

    private void SpawnParticle(bool randomY)
    {
        GameObject go = Instantiate(particlePrefab, transform);

        float x = Random.Range(-spawnRangeX, spawnRangeX);
        float y = randomY ? Random.Range(-spawnRangeY, spawnRangeY) : -spawnRangeY;
        go.transform.position = new Vector3(x, y, 0.5f);

        float scale = Random.Range(minScale, maxScale);
        go.transform.localScale = Vector3.one * scale;

        Color col = neonColors[Random.Range(0, neonColors.Length)];

        SpriteRenderer sr = go.GetComponent<SpriteRenderer>();

        Particle p = new Particle
        {
            transform   = go.transform,
            sr          = sr,
            speed       = Random.Range(minDriftSpeed, maxDriftSpeed),
            driftX      = Random.Range(-maxHorizontalDrift, maxHorizontalDrift),
            phaseOffset = Random.Range(0f, Mathf.PI * 2f),
            color       = col
        };

        if (sr != null)
        {
            sr.color       = col;
            sr.sortingOrder = -10; // behind everything
        }

        particles.Add(p);
    }
}
