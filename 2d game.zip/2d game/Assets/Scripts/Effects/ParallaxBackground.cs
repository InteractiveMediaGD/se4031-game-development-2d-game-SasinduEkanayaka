using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Multi-layer parallax scrolling background.
/// Each layer moves at a fraction of the world scroll speed, creating a sense of depth.
/// Layers seamlessly loop by teleporting back to the right when they scroll too far left.
///
/// Setup:
///   1. Create wide sprite GameObjects for each background layer (far → near).
///   2. Add them to the layers list with increasing speedMultiplier values.
///   3. Make sure each sprite is wide enough to fill the gap during the teleport.
///
/// Recommended layer multipliers:
///   Far (stars/sky)  : 0.15
///   Mid (ruins/arches): 0.35
///   Near (columns)   : 0.60
/// </summary>
public class ParallaxBackground : MonoBehaviour
{
    [System.Serializable]
    public class ParallaxLayer
    {
        [Tooltip("The Transform of this background sprite.")]
        public Transform layerTransform;

        [Range(0f, 1f)]
        [Tooltip("0 = stationary, 1 = scrolls at full world speed.")]
        public float speedMultiplier = 0.5f;

        [HideInInspector] public float spriteWidth;
    }

    [SerializeField] private List<ParallaxLayer> layers = new List<ParallaxLayer>();

    [Tooltip("When a layer's X falls below this value, it is wrapped to the right.")]
    [SerializeField] private float wrapTriggerX = -22f;

    [Tooltip("The X position layers are moved to when they wrap.")]
    [SerializeField] private float wrapTargetX  = 22f;

    private void Start()
    {
        // Cache sprite widths to avoid per-frame GetComponent calls
        foreach (var layer in layers)
        {
            if (layer.layerTransform == null) continue;
            SpriteRenderer sr = layer.layerTransform.GetComponent<SpriteRenderer>();
            layer.spriteWidth = sr != null ? sr.bounds.size.x : 20f;
        }
    }

    private void Update()
    {
        if (GameManager.Instance == null) return;

        float baseSpeed = GameManager.Instance.ScrollSpeed;

        foreach (var layer in layers)
        {
            if (layer.layerTransform == null) continue;

            // Move left at a fraction of the world speed (parallax effect)
            float speed = baseSpeed * layer.speedMultiplier;
            layer.layerTransform.Translate(Vector3.left * speed * Time.deltaTime);

            // Seamless loop: when far enough left, jump to the right
            if (layer.layerTransform.position.x < wrapTriggerX)
            {
                Vector3 pos = layer.layerTransform.position;
                pos.x = wrapTargetX;
                layer.layerTransform.position = pos;
            }
        }
    }
}
