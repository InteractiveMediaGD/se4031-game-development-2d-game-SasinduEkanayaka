using UnityEngine;
using UnityEngine.UI;
using TMPro;

/// <summary>
/// NEON VOID SURVIVOR – Neon Pulse Effect
/// ══════════════════════════════════════════════════════════════
/// Pulses the alpha/color of a UI element or SpriteRenderer
/// to create a neon glow flicker effect.
///
/// Works with:
///   • TextMeshProUGUI (score, labels)
///   • Image (UI panels, decorative lines)
///   • SpriteRenderer (world-space sprites)
///
/// Attach directly to the UI element or GameObject to animate.
/// ══════════════════════════════════════════════════════════════
/// </summary>
public class NeonPulseEffect : MonoBehaviour
{
    // ─── Mode ──────────────────────────────────────────────────────────────────
    public enum PulseTarget { TextMeshPro, Image, SpriteRenderer }

    [Header("Target Type")]
    [SerializeField] private PulseTarget targetType = PulseTarget.TextMeshPro;

    // ─── Pulse Settings ────────────────────────────────────────────────────────
    [Header("Pulse")]
    [Tooltip("Speed of the pulse oscillation (higher = faster flicker).")]
    [SerializeField] private float pulseSpeed = 2.0f;

    [Tooltip("Minimum alpha (0 = fully transparent at lowest point).")]
    [Range(0f, 1f)]
    [SerializeField] private float alphaMin = 0.6f;

    [Tooltip("Maximum alpha (1 = fully opaque at peak).")]
    [Range(0f, 1f)]
    [SerializeField] private float alphaMax = 1.0f;

    [Tooltip("If true, also pulses the color between baseColor and pulseColor.")]
    [SerializeField] private bool pulseColor = false;

    [SerializeField] private Color baseColor  = Color.white;
    [SerializeField] private Color pulseColor_= new Color(0f, 1f, 1f); // cyan neon

    // ─── Cached Components ─────────────────────────────────────────────────────
    private TextMeshProUGUI tmp;
    private Image           img;
    private SpriteRenderer  sr;

    // ─── Runtime ───────────────────────────────────────────────────────────────
    private float timer;
    private Color startColor;

    // ─────────────────────────────────────────────────────────────────────────
    private void Awake()
    {
        switch (targetType)
        {
            case PulseTarget.TextMeshPro:
                tmp = GetComponent<TextMeshProUGUI>();
                if (tmp != null) startColor = tmp.color;
                break;
            case PulseTarget.Image:
                img = GetComponent<Image>();
                if (img != null) startColor = img.color;
                break;
            case PulseTarget.SpriteRenderer:
                sr = GetComponent<SpriteRenderer>();
                if (sr != null) startColor = sr.color;
                break;
        }
    }

    private void Update()
    {
        timer += Time.unscaledDeltaTime * pulseSpeed;
        float t     = (Mathf.Sin(timer) + 1f) * 0.5f;          // 0 → 1 → 0
        float alpha = Mathf.Lerp(alphaMin, alphaMax, t);

        Color c = pulseColor
            ? Color.Lerp(baseColor, pulseColor_, t)
            : startColor;
        c.a = alpha;

        ApplyColor(c);
    }

    private void ApplyColor(Color c)
    {
        switch (targetType)
        {
            case PulseTarget.TextMeshPro:
                if (tmp != null) tmp.color = c;
                break;
            case PulseTarget.Image:
                if (img != null) img.color = c;
                break;
            case PulseTarget.SpriteRenderer:
                if (sr  != null) sr.color  = c;
                break;
        }
    }
}
