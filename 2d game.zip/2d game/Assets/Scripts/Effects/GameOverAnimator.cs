using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

/// <summary>
/// NEON VOID SURVIVOR – Game Over Screen Animator
/// ══════════════════════════════════════════════════════════════
/// Animates the game over panel entrance:
///   1. Black overlay fades in
///   2. "GAME OVER" title slides down from above + fades in
///   3. Final score counts up (satisfying number roll)
///   4. Buttons fade in from below
///
/// Uses Time.unscaledDeltaTime so animations play even with
/// Time.timeScale = 0 (which GameManager sets on game over).
/// ══════════════════════════════════════════════════════════════
/// Attach to the GameOverPanel GameObject.
/// Subscribe to GameManager.OnGameOver event to trigger ShowPanel().
/// </summary>
public class GameOverAnimator : MonoBehaviour
{
    // ─── UI References ─────────────────────────────────────────────────────────
    [Header("Overlay")]
    [Tooltip("Semi-transparent black Image behind the panel content.")]
    [SerializeField] private Image backgroundOverlay;
    [Tooltip("Target alpha for the overlay (e.g. 0.85).")]
    [SerializeField] private float overlayTargetAlpha = 0.85f;

    [Header("Title")]
    [Tooltip("'GAME OVER' TextMeshProUGUI element.")]
    [SerializeField] private RectTransform titleTransform;
    [SerializeField] private CanvasGroup   titleGroup;
    [Tooltip("Title starts this many units above its resting position.")]
    [SerializeField] private float titleSlideOffset = 80f;

    [Header("Score")]
    [Tooltip("'FINAL SCORE' label TextMeshPro.")]
    [SerializeField] private TextMeshProUGUI finalScoreLabel;
    [Tooltip("How long the score counts up.")]
    [SerializeField] private float scoreRollDuration = 1.0f;

    [Header("Buttons")]
    [SerializeField] private CanvasGroup buttonsGroup;
    [Tooltip("Buttons start this many units below their rest position.")]
    [SerializeField] private float buttonsSlideOffset = 40f;
    [SerializeField] private RectTransform buttonsTransform;

    [Header("Timing")]
    [SerializeField] private float overlayFadeDuration = 0.4f;
    [SerializeField] private float titleAnimDuration   = 0.55f;
    [SerializeField] private float delayBeforeScore    = 0.2f;
    [SerializeField] private float delayBeforeButtons  = 0.3f;
    [SerializeField] private float buttonFadeDuration  = 0.45f;

    // ─── Scene References ──────────────────────────────────────────────────────
    [Header("Scene Names")]
    [SerializeField] private string mainMenuSceneName = "MainMenu";

    // ─── Private State ─────────────────────────────────────────────────────────
    private Vector2 titleRestPos;
    private Vector2 buttonsRestPos;
    private int     finalScore;

    // ─────────────────────────────────────────────────────────────────────────
    private void Awake()
    {
        // Cache resting positions
        if (titleTransform   != null) titleRestPos   = titleTransform.anchoredPosition;
        if (buttonsTransform != null) buttonsRestPos = buttonsTransform.anchoredPosition;
    }

    private void OnEnable()
    {
        // Grab final score from GameManager whenever the panel is activated
        finalScore = GameManager.Instance != null ? GameManager.Instance.CurrentScore : 0;
        StartCoroutine(PlayEntranceAnimation());
    }

    // ─── Entrance Animation ────────────────────────────────────────────────────

    private IEnumerator PlayEntranceAnimation()
    {
        // ── Reset to start states ─────────────────────────────────────────────
        SetOverlayAlpha(0f);
        if (titleGroup     != null) titleGroup.alpha     = 0f;
        if (buttonsGroup   != null) buttonsGroup.alpha   = 0f;
        if (finalScoreLabel != null) finalScoreLabel.text = "0";

        if (titleTransform  != null)
            titleTransform.anchoredPosition  = titleRestPos  + Vector2.up * titleSlideOffset;
        if (buttonsTransform != null)
            buttonsTransform.anchoredPosition = buttonsRestPos - Vector2.up * buttonsSlideOffset;

        // ── Step 1: Overlay fade in ────────────────────────────────────────────
        yield return StartCoroutine(FadeOverlay(0f, overlayTargetAlpha, overlayFadeDuration));

        // ── Step 2: Title slide + fade in ─────────────────────────────────────
        float elapsed = 0f;
        Vector2 titleStart = titleRestPos + Vector2.up * titleSlideOffset;
        while (elapsed < titleAnimDuration)
        {
            elapsed += Time.unscaledDeltaTime;
            float t  = Mathf.Clamp01(elapsed / titleAnimDuration);
            float te = EaseOutCubic(t);

            if (titleGroup     != null) titleGroup.alpha = te;
            if (titleTransform != null)
                titleTransform.anchoredPosition = Vector2.Lerp(titleStart, titleRestPos, te);

            yield return null;
        }
        if (titleGroup     != null) titleGroup.alpha              = 1f;
        if (titleTransform != null) titleTransform.anchoredPosition = titleRestPos;

        yield return new WaitForSecondsRealtime(delayBeforeScore);

        // ── Step 3: Score count-up ─────────────────────────────────────────────
        yield return StartCoroutine(RollScore(finalScore));

        yield return new WaitForSecondsRealtime(delayBeforeButtons);

        // ── Step 4: Buttons slide up + fade in ────────────────────────────────
        elapsed = 0f;
        Vector2 buttonsStart = buttonsRestPos - Vector2.up * buttonsSlideOffset;
        while (elapsed < buttonFadeDuration)
        {
            elapsed += Time.unscaledDeltaTime;
            float t  = Mathf.Clamp01(elapsed / buttonFadeDuration);
            float te = EaseOutCubic(t);

            if (buttonsGroup    != null) buttonsGroup.alpha = te;
            if (buttonsTransform != null)
                buttonsTransform.anchoredPosition = Vector2.Lerp(buttonsStart, buttonsRestPos, te);

            yield return null;
        }
        if (buttonsGroup    != null) { buttonsGroup.alpha = 1f; buttonsGroup.interactable = true; buttonsGroup.blocksRaycasts = true; }
        if (buttonsTransform != null) buttonsTransform.anchoredPosition = buttonsRestPos;
    }

    // ─── Score Roll ────────────────────────────────────────────────────────────

    private IEnumerator RollScore(int target)
    {
        if (finalScoreLabel == null) yield break;
        float elapsed = 0f;
        while (elapsed < scoreRollDuration)
        {
            elapsed += Time.unscaledDeltaTime;
            float t  = Mathf.Clamp01(elapsed / scoreRollDuration);
            int   displayed = Mathf.RoundToInt(Mathf.Lerp(0, target, EaseOutCubic(t)));
            finalScoreLabel.text = displayed.ToString("D6");
            yield return null;
        }
        finalScoreLabel.text = target.ToString("D6");
    }

    // ─── Button Callbacks ──────────────────────────────────────────────────────

    /// <summary>Restart: reload current game scene. Called by Restart button's OnClick.</summary>
    public void OnRestartClicked()
    {
        Time.timeScale = 1f;
        UnityEngine.SceneManagement.SceneManager.LoadScene(
            UnityEngine.SceneManagement.SceneManager.GetActiveScene().buildIndex);
    }

    /// <summary>Main Menu: load menu scene. Called by Main Menu button's OnClick.</summary>
    public void OnMainMenuClicked()
    {
        Time.timeScale = 1f;
        UnityEngine.SceneManagement.SceneManager.LoadScene(mainMenuSceneName);
    }

    // ─── Helpers ───────────────────────────────────────────────────────────────

    private IEnumerator FadeOverlay(float from, float to, float duration)
    {
        float elapsed = 0f;
        while (elapsed < duration)
        {
            elapsed += Time.unscaledDeltaTime;
            SetOverlayAlpha(Mathf.Lerp(from, to, elapsed / duration));
            yield return null;
        }
        SetOverlayAlpha(to);
    }

    private void SetOverlayAlpha(float alpha)
    {
        if (backgroundOverlay != null)
            backgroundOverlay.color = new Color(0f, 0f, 0f, alpha);
    }

    private static float EaseOutCubic(float t)
    {
        return 1f - Mathf.Pow(1f - t, 3f);
    }
}
