using System.Collections;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

/// <summary>
/// NEON VOID SURVIVOR – Button Hover Effect
/// ══════════════════════════════════════════════════════════════
/// Adds a premium feel to UI buttons:
///   • Smooth scale pop on hover
///   • Color shift on hover (neon glow tint)
///   • Scale punch on click
///
/// Implements IPointerEnterHandler, IPointerExitHandler,
/// and IPointerClickHandler — no EventTrigger component needed.
///
/// Attach to each Button GameObject alongside a Button component.
/// ══════════════════════════════════════════════════════════════
/// </summary>
[RequireComponent(typeof(RectTransform))]
public class ButtonHoverEffect : MonoBehaviour,
    IPointerEnterHandler, IPointerExitHandler,
    IPointerDownHandler, IPointerUpHandler
{
    // ─── Scale Settings ────────────────────────────────────────────────────────
    [Header("Scale")]
    [Tooltip("Scale multiplier when hovered.")]
    [SerializeField] private float hoverScale  = 1.08f;
    [Tooltip("Scale multiplier when pressed.")]
    [SerializeField] private float pressScale  = 0.94f;
    [Tooltip("Speed at which scale animates.")]
    [SerializeField] private float scaleSpeed  = 10f;

    // ─── Color Settings ────────────────────────────────────────────────────────
    [Header("Color")]
    [Tooltip("Optional Image to tint on hover (usually the button background).")]
    [SerializeField] private Image targetImage;
    [SerializeField] private Color normalColor = new Color(0.06f, 0.06f, 0.20f, 0.90f);
    [SerializeField] private Color hoverColor  = new Color(0.00f, 0.75f, 1.00f, 0.95f);
    [Tooltip("Speed of the color lerp.")]
    [SerializeField] private float colorSpeed  = 8f;

    // ─── Sound (optional) ──────────────────────────────────────────────────────
    [Header("Sound (optional)")]
    [SerializeField] private AudioSource audioSource;
    [SerializeField] private AudioClip   hoverSound;
    [SerializeField] private AudioClip   clickSound;
    [SerializeField] [Range(0f,1f)] private float hoverVolume = 0.35f;
    [SerializeField] [Range(0f,1f)] private float clickVolume = 0.55f;

    // ─── Runtime ───────────────────────────────────────────────────────────────
    private RectTransform rt;
    private float         targetScale    = 1f;
    private Color         targetColor;
    private bool          isHovered;

    // ─────────────────────────────────────────────────────────────────────────
    private void Awake()
    {
        rt          = GetComponent<RectTransform>();
        targetColor = normalColor;
        if (targetImage != null) targetImage.color = normalColor;
    }

    private void Update()
    {
        // Smoothly interpolate scale
        float current = rt.localScale.x;
        float next    = Mathf.Lerp(current, targetScale, Time.unscaledDeltaTime * scaleSpeed);
        rt.localScale = Vector3.one * next;

        // Smoothly interpolate color
        if (targetImage != null)
            targetImage.color = Color.Lerp(targetImage.color, targetColor,
                                           Time.unscaledDeltaTime * colorSpeed);
    }

    // ─── Pointer Events ────────────────────────────────────────────────────────

    public void OnPointerEnter(PointerEventData _)
    {
        isHovered   = true;
        targetScale = hoverScale;
        targetColor = hoverColor;
        PlaySound(hoverSound, hoverVolume);
    }

    public void OnPointerExit(PointerEventData _)
    {
        isHovered   = false;
        targetScale = 1f;
        targetColor = normalColor;
    }

    public void OnPointerDown(PointerEventData _)
    {
        targetScale = pressScale;
        PlaySound(clickSound, clickVolume);
    }

    public void OnPointerUp(PointerEventData _)
    {
        targetScale = isHovered ? hoverScale : 1f;
    }

    // ─── Audio ─────────────────────────────────────────────────────────────────

    private void PlaySound(AudioClip clip, float volume)
    {
        if (audioSource != null && clip != null)
            audioSource.PlayOneShot(clip, volume);
    }
}
