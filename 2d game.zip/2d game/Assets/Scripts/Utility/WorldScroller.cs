using UnityEngine;

/// <summary>
/// Moves this GameObject leftward at the current world scroll speed.
/// Use on any simple object that should scroll uniformly with the world
/// (e.g. decorative background elements not covered by ParallaxBackground).
///
/// Most gameplay objects (EnemyController, HealthPackPickup) handle their own
/// movement, but this component is useful for foreground details.
/// </summary>
public class WorldScroller : MonoBehaviour
{
    [Tooltip("Speed relative to GameManager.ScrollSpeed (1 = full, 0.5 = half).")]
    [SerializeField] private float speedMultiplier = 1f;

    private void Update()
    {
        if (GameManager.Instance == null || GameManager.Instance.IsGameOver) return;

        float speed = GameManager.Instance.ScrollSpeed * speedMultiplier;
        transform.Translate(Vector3.left * speed * Time.deltaTime);
    }
}
