using UnityEngine;

/// <summary>
/// Destroys this GameObject when it scrolls past the left edge of the screen.
///
/// Attach to: EnemyController, HealthPackPickup, ObstacleSegment.
/// Set destroyX to slightly past the left camera edge (e.g. -15 for a
/// camera with orthographic size 5 and a standard aspect ratio).
///
/// ASSIGNMENT COMPLIANCE:
///  ✓ Enemies destroyed shortly after player passes them
///  ✓ Health packs destroyed shortly after player passes them
/// </summary>
public class AutoDestroyOffscreen : MonoBehaviour
{
    [Tooltip("X position at which this object is destroyed (left off-screen).")]
    [SerializeField] private float destroyX = -15f;

    private void Update()
    {
        if (transform.position.x < destroyX)
            Destroy(gameObject);
    }
}
