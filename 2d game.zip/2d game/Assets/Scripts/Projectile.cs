using UnityEngine;

/// <summary>
/// Projectile behavior - flies forward at high speed and destroys enemies.
/// </summary>
public class Projectile : MonoBehaviour
{
    [Header("Movement")]
    [Tooltip("Speed of the projectile")]
    [SerializeField] private float speed = 20f;

    [Header("Lifetime")]
    [Tooltip("Time before auto-destroy (seconds)")]
    [SerializeField] private float lifetime = 3f;

    private Rigidbody2D rb;
    private Vector2 direction = Vector2.right;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    private void Start()
    {
        // Set velocity along configured direction
        if (rb != null)
        {
            rb.velocity = direction * speed;
        }
        
        // Auto-destroy after lifetime expires
        Destroy(gameObject, lifetime);
    }

    /// <summary>
    /// Sets projectile travel direction before Start() executes.
    /// </summary>
    public void SetDirection(Vector2 dir)
    {
        if (dir.sqrMagnitude > 0f)
            direction = dir.normalized;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        // Check if we hit an enemy
        if (other.CompareTag("Enemy"))
        {
            EnemyController modernEnemy = other.GetComponent<EnemyController>();
            if (modernEnemy != null)
            {
                modernEnemy.DestroyEnemy(awardScore: true);
            }

            // Try EnemyAntivirus first
            EnemyAntivirus enemy = other.GetComponent<EnemyAntivirus>();
            if (enemy != null)
            {
                enemy.OnHitByProjectile();
            }
            
            // Also try EnemyShooter
            EnemyShooter shooter = other.GetComponent<EnemyShooter>();
            if (shooter != null)
            {
                shooter.OnHitByProjectile();
            }
            
            // Destroy this projectile
            Destroy(gameObject);
        }
        
        // Destroy on colliding with world blockers
        if (other.CompareTag("Wall") || other.CompareTag("Obstacle") || other.CompareTag("Boundary"))
        {
            Destroy(gameObject);
        }
    }
}
