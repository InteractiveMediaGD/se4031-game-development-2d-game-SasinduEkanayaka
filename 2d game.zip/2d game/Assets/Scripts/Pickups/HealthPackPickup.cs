using UnityEngine;

/// <summary>
/// Arcane Orb health pickup – restores player health on contact.
/// Bobs up and down for readability and drifts leftward with the world.
/// Destroyed immediately on pickup, or automatically when off-screen.
///
/// ASSIGNMENT COMPLIANCE:
///  ✓ Health pack is a collidable pickup (CircleCollider2D isTrigger)
///  ✓ Destroyed when player collects it (Destroy on trigger)
///  ✓ Destroyed shortly after player passes it (AutoDestroyOffscreen component)
///  ✓ Increases health up to max only (Heal is clamped in GameManager)
///  ✓ Visually distinct from enemies: round, green/gold colour vs triangular enemies
///
/// GameObject setup:
///   Tag: "HealthPack"  (or leave untagged; detection uses CompareTag("Player"))
///   CircleCollider2D: isTrigger = true
///   AutoDestroyOffscreen component (destroyX ≈ -15)
/// </summary>
public class HealthPackPickup : MonoBehaviour
{
    [Header("Healing")]
    [Tooltip("HP restored when the player collects this pickup.")]
    [SerializeField] private int healAmount = 30;

    [Header("Bob Animation")]
    [Tooltip("Vertical bob amplitude in world units.")]
    [SerializeField] private float bobAmplitude = 0.22f;
    [Tooltip("Bob speed (cycles per second).")]
    [SerializeField] private float bobFrequency = 2f;

    [Header("Effects")]
    [Tooltip("Optional particle burst spawned on pickup.")]
    [SerializeField] private GameObject pickupEffectPrefab;

    private float startY;
    private float birthTime;

    private void OnEnable()
    {
        startY    = transform.position.y;
        birthTime = Time.time;
    }

    private void Update()
    {
        if (GameManager.Instance == null || GameManager.Instance.IsGameOver) return;

        // Scroll leftward with the world
        float scrollSpeed = GameManager.Instance.ScrollSpeed;
        transform.Translate(Vector3.left * scrollSpeed * Time.deltaTime);

        // Gentle bobbing makes it stand out visually
        float newY = startY + Mathf.Sin((Time.time - birthTime) * bobFrequency) * bobAmplitude;
        transform.position = new Vector3(transform.position.x, newY, 0f);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (!other.CompareTag("Player")) return;

        // Heal (GameManager clamps to maxHealth automatically)
        GameManager.Instance?.Heal(healAmount);

        // Show floating "+30 HP" popup
        UIManager.Instance?.SpawnScorePopup(healAmount, transform.position, isHeal: true);

        // Spawn pickup particle effect
        if (pickupEffectPrefab != null)
            Instantiate(pickupEffectPrefab, transform.position, Quaternion.identity);

        Destroy(gameObject);
    }
}
