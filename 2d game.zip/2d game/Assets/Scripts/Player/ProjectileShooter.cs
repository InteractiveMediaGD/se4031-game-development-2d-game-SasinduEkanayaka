using UnityEngine;

/// <summary>
/// Fires arcane bolt projectiles toward the mouse cursor on left click (hold to auto-fire).
/// In Fury Mode (low health) the spawned projectile is visually intensified.
///
/// ASSIGNMENT COMPLIANCE:
///  ✓ Left mouse click creates a projectile attack
///  ✓ Projectile shoots correctly toward mouse direction
///  ✓ Fire rate limiter prevents spam (nextFireTime check)
///
/// Attach to the Player GameObject.
/// Assign projectilePrefab and optionally a FirePoint child transform.
/// </summary>
public class ProjectileShooter : MonoBehaviour
{
    [Header("Projectile")]
    [Tooltip("The arcane bolt prefab to instantiate on fire.")]
    [SerializeField] private GameObject projectilePrefab;

    [Tooltip("Where the bolt spawns. Auto-created if left empty.")]
    [SerializeField] private Transform firePoint;

    [Header("Fire Rate")]
    [Tooltip("Minimum seconds between shots (hold mouse to auto-fire).")]
    [SerializeField] private float fireRate = 0.28f;

    [Header("Fury Mode Visuals")]
    [Tooltip("Normal bolt colour (arcane blue).")]
    [SerializeField] private Color normalColor  = new Color(0.35f, 0.75f, 1f);
    [Tooltip("Fury bolt colour (fiery orange-red).")]
    [SerializeField] private Color furyColor    = new Color(1f, 0.38f, 0.05f);
    [Tooltip("Scale multiplier applied to projectile in Fury Mode.")]
    [SerializeField] private Vector3 furyScale  = new Vector3(1.6f, 1.6f, 1f);

    private float nextFireTime;
    private Camera mainCamera;

    private void Start()
    {
        mainCamera = Camera.main;

        // Auto-create a fire point slightly in front of the player if none assigned
        if (firePoint == null)
        {
            var fp = new GameObject("FirePoint");
            fp.transform.SetParent(transform);
            fp.transform.localPosition = new Vector3(0.55f, 0f, 0f);
            firePoint = fp.transform;
        }
    }

    private void Update()
    {
        if (GameManager.Instance == null || GameManager.Instance.IsGameOver) return;

        // Hold left mouse button to fire continuously at the fire rate
        if (Input.GetMouseButton(0) && Time.time >= nextFireTime)
        {
            Fire();
        }
    }

    private void Fire()
    {
        if (projectilePrefab == null)
        {
            Debug.LogWarning("[ProjectileShooter] projectilePrefab is not assigned.");
            return;
        }

        nextFireTime = Time.time + fireRate;

        // Direction: from fire point toward the mouse cursor in world space
        Vector3 mouseWorld = mainCamera.ScreenToWorldPoint(Input.mousePosition);
        mouseWorld.z = 0f;
        Vector2 direction = ((Vector2)mouseWorld - (Vector2)firePoint.position).normalized;

        // Spawn projectile
        GameObject projGO = Instantiate(projectilePrefab, firePoint.position, Quaternion.identity);

        // Rotate sprite to face movement direction (bolt points toward cursor)
        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        projGO.transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);

        // Pass direction to the projectile's movement script
        Projectile proj = projGO.GetComponent<Projectile>();
        proj?.SetDirection(direction);

        // Fury Mode: tint and scale up the projectile
        bool inFury = FuryModeController.Instance != null && FuryModeController.Instance.IsFuryActive;
        SpriteRenderer sr = projGO.GetComponent<SpriteRenderer>();
        if (sr != null) sr.color = inFury ? furyColor : normalColor;
        if (inFury)     projGO.transform.localScale = furyScale;

        // Subtle camera kick on shoot
        CameraEffects.Instance?.ShakeOnShoot();
    }
}
