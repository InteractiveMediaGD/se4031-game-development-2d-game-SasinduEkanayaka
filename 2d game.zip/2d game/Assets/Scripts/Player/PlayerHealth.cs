using System.Collections;
using UnityEngine;

/// <summary>
/// Manages player invincibility frames and the sprite flash effect on damage.
/// Handles collision-based damage events (obstacles and enemy contact).
///
/// ASSIGNMENT COMPLIANCE:
///  ✓ Health decreases on obstacle collision – delegates to GameManager.TakeDamage
///  ✓ Player passes THROUGH obstacles after damage (walls are isTrigger, no physics block)
///  ✓ Player only dies when health reaches 0
///  ✓ Enemies are destroyed when they contact the player
///  ✓ Invincibility prevents rapid successive damage from a single overlap
///
/// Tags required on colliders:
///   "Obstacle"  – on obstacle wall trigger colliders
///   "Enemy"     – on enemy trigger colliders
/// </summary>
public class PlayerHealth : MonoBehaviour
{
    [Header("Damage Values")]
    [Tooltip("Health lost when touching an obstacle wall.")]
    [SerializeField] private int obstacleDamage = 20;
    [Tooltip("Health lost when ramming into an enemy (no score awarded).")]
    [SerializeField] private int enemyContactDamage = 25;

    [Header("Invincibility Frames")]
    [Tooltip("Seconds of invincibility after taking any damage.")]
    [SerializeField] private float invincibilityDuration = 1.5f;
    [Tooltip("Sprite flashes this fast during invincibility.")]
    [SerializeField] private float flashInterval = 0.1f;

    private bool isInvincible;
    private SpriteRenderer sr;

    public bool IsInvincible => isInvincible;

    private void Awake()
    {
        sr = GetComponent<SpriteRenderer>();
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        // Ignore all collisions while invincible or after game over
        if (isInvincible) return;
        if (GameManager.Instance == null || GameManager.Instance.IsGameOver) return;

        if (other.CompareTag("Obstacle"))
        {
            // Hit a wall – take damage, start I-frames, player passes through freely
            GameManager.Instance.TakeDamage(obstacleDamage);
            CameraEffects.Instance?.ShakeOnDamage();
            CameraEffects.Instance?.FlashDamageVignette();
            StartCoroutine(InvincibilityRoutine());
        }
        else if (other.CompareTag("Enemy"))
        {
            // Ram an enemy – damage player, destroy enemy (no score for ramming)
            GameManager.Instance.TakeDamage(enemyContactDamage);
            CameraEffects.Instance?.ShakeOnDamage();
            CameraEffects.Instance?.FlashDamageVignette();
            StartCoroutine(InvincibilityRoutine());

            EnemyController enemy = other.GetComponent<EnemyController>();
            enemy?.DestroyEnemy(awardScore: false);
        }
    }

    /// <summary>
    /// Flashes the sprite and sets the invincibility window.
    /// Called from external scripts (e.g. if other systems deal damage directly).
    /// </summary>
    public void TriggerInvincibility()
    {
        if (!isInvincible) StartCoroutine(InvincibilityRoutine());
    }

    private IEnumerator InvincibilityRoutine()
    {
        isInvincible = true;
        float elapsed = 0f;

        while (elapsed < invincibilityDuration)
        {
            if (sr != null)
            {
                // Alternate between red tint and transparent – clear visual feedback
                bool showRed = (elapsed % (flashInterval * 2f)) < flashInterval;
                sr.color = showRed
                    ? new Color(1f, 0.35f, 0.35f, 1f)
                    : new Color(1f, 1f, 1f, 0.35f);
            }
            yield return new WaitForSeconds(flashInterval);
            elapsed += flashInterval;
        }

        if (sr != null) sr.color = Color.white; // restore normal appearance
        isInvincible = false;
    }
}
