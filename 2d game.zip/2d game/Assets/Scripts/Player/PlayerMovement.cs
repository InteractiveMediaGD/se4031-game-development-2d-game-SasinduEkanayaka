using UnityEngine;

/// <summary>
/// Controls the player's vertical movement (W/S or Arrow Keys).
/// The player is FIXED on the X-axis; the world scrolls left past them.
/// This means no CameraFollow is needed – the camera is completely static.
///
/// Rigidbody2D constraints: Freeze X Position + Freeze Rotation.
/// Gravity Scale: 0 (floating character).
/// </summary>
[RequireComponent(typeof(Rigidbody2D))]
public class PlayerMovement : MonoBehaviour
{
    [Header("Movement")]
    [Tooltip("Vertical movement speed in world units per second.")]
    [SerializeField] private float moveSpeed = 6f;

    [Header("Screen Bounds")]
    [Tooltip("Lowest Y the player can reach (match camera bottom edge).")]
    [SerializeField] private float minY = -3.8f;
    [Tooltip("Highest Y the player can reach (match camera top edge).")]
    [SerializeField] private float maxY = 3.8f;

    private Rigidbody2D rb;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        rb.gravityScale = 0f;
        rb.constraints = RigidbodyConstraints2D.FreezePositionX
                       | RigidbodyConstraints2D.FreezeRotation;
    }

    private void FixedUpdate()
    {
        if (GameManager.Instance != null && GameManager.Instance.IsGameOver)
        {
            rb.velocity = Vector2.zero;
            return;
        }

        float inputY = Input.GetAxisRaw("Vertical"); // W/S or Up/Down arrows → -1, 0, +1
        rb.velocity = new Vector2(0f, inputY * moveSpeed);

        // Hard-clamp so the sprite never exits the play area
        Vector3 pos = transform.position;
        pos.y = Mathf.Clamp(pos.y, minY, maxY);
        transform.position = pos;

        // Stop vertical velocity if already at a boundary
        if ((pos.y <= minY && inputY < 0f) || (pos.y >= maxY && inputY > 0f))
            rb.velocity = Vector2.zero;
    }
}
